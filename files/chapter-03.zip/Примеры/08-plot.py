import pandas as pd
import matplotlib.pyplot as plt

raw = pd.read_csv("delivery.csv")
clean = raw.drop_duplicates().dropna(subset=["price"])
train = clean.loc[clean["split"] == "train"]
standard = train.loc[train["service"] == "standard"]
express = train.loc[train["service"] == "express"]

plt.figure(figsize=(6.4, 3.6))
plt.scatter(standard["distance_km"], standard["price"],
            label="Обычная", marker="o", color="#31566B")
plt.scatter(express["distance_km"], express["price"],
            label="Срочная", marker="^", color="#242424")
plt.xlabel("Расстояние, км")
plt.ylabel("Стоимость, усл. ед.")
plt.legend()
plt.grid(alpha=0.22)
plt.tight_layout()
plt.savefig("delivery-plot.png", dpi=240)
print("Точек", len(train))
print("Сохранён delivery-plot.png")
