import numpy as np

train_distance = np.array([1, 2, 4, 5, 2, 4, 6])
test_distance = np.array([3, 8, 6])
low = train_distance.min()
high = train_distance.max()
span = high - low

scaled_test = (test_distance - low) / span
print("Границы", low, high)
print("Масштаб test", scaled_test.round(2).tolist())
