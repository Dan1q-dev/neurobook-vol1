import pandas as pd

raw = pd.read_csv("delivery.csv")
labelled = raw.drop_duplicates().dropna(subset=["price"])
train = labelled.loc[labelled["split"] == "train"]
test = labelled.loc[labelled["split"] == "test"]

typical_weight = train["weight_kg"].median()
train_weight = train["weight_kg"].fillna(typical_weight)
test_weight = test["weight_kg"].fillna(typical_weight)

print("Медиана", typical_weight)
print("Масса в train", train_weight.tolist())
print("Масса в test", test_weight.tolist())
