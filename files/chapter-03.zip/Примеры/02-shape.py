import numpy as np

features = np.array([[1, 1], [2, 2], [4, 3]])

print("Размер", features.shape)
print("Вторая строка, первый столбец", features[1, 0])
print("Расстояния", features[:, 0].tolist())
print("Средние по столбцам",
      features.mean(axis=0).round(2).tolist())
