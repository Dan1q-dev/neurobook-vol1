order = {"order_id": 106, "service": "express"}
order["weight_kg"] = 2

print(order["service"])
print(order["weight_kg"])
print(order.get("price", "цена неизвестна"))
