import pandas as pd

table = pd.read_csv("delivery.csv", encoding="utf-8")
print("Строк и столбцов", table.shape)

columns = ["order_id", "distance_km", "service"]
print(table[columns].head(3).to_string(index=False))
