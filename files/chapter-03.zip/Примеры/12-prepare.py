import pandas as pd

def make_features(rows, typical_weight, low, span):
    service = rows["service"]
    if not service.isin(["standard", "express"]).all():
        raise ValueError("Неизвестный тип доставки")
    return pd.DataFrame({
        "distance_scaled": (rows["distance_km"] - low) / span,
        "weight_kg": rows["weight_kg"].fillna(typical_weight),
        "service_standard": (service == "standard").astype(int),
        "service_express": (service == "express").astype(int),
    })

raw = pd.read_csv("delivery.csv")
clean = raw.drop_duplicates()
if clean["order_id"].duplicated().any():
    raise ValueError("Один номер имеет разные записи")
labelled = clean.dropna(subset=["price"])
train = labelled.loc[labelled["split"] == "train"]
test = labelled.loc[labelled["split"] == "test"]

weight = train["weight_kg"].median()
low = train["distance_km"].min()
span = train["distance_km"].max() - low
if pd.isna(weight) or not span > 0:
    raise ValueError("Проверьте массу и разброс расстояний в train")

X_train = make_features(train, weight, low, span).to_numpy()
X_test = make_features(test, weight, low, span).to_numpy()
y_train = train["price"].to_numpy()
y_test = test["price"].to_numpy()
print("Обучение", X_train.shape, y_train.shape)
print("Проверка", X_test.shape, y_test.shape)
for number, features in zip(test["order_id"], X_test):
    print("Заказ", number, features.round(2).tolist())
