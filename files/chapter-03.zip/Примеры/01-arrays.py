import numpy as np

distances = np.array([1, 2, 4, 5])
actual = np.array([5, 8, 14, 17])

predictions = 2 * distances + 1
errors = np.abs(predictions - actual)

print("Размер", distances.shape)
print("Предсказания", predictions.tolist())
print("Ошибки", errors.tolist())
print("MAE", errors.mean())
