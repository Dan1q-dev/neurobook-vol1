import pandas as pd

service = pd.Series(["standard", "express", "standard"])
flags = pd.DataFrame({
    "service_standard": (service == "standard").astype(int),
    "service_express": (service == "express").astype(int),
})

print(flags.columns.tolist())
print(flags.to_numpy().tolist())
