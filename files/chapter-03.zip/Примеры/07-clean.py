import pandas as pd

raw = pd.read_csv("delivery.csv")
clean = raw.drop_duplicates()
if clean["order_id"].duplicated().any():
    raise ValueError("Один номер имеет разные записи")

labelled = clean.dropna(subset=["price"])
train = labelled.loc[labelled["split"] == "train"]
test = labelled.loc[labelled["split"] == "test"]

print("После удаления копий", len(clean))
print("С известной ценой", len(labelled))
print("Обучение", len(train), "проверка", len(test))
