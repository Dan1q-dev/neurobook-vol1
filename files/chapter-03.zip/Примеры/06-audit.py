import pandas as pd

raw = pd.read_csv("delivery.csv")
missing = raw.isna().sum()

print("Без массы", missing["weight_kg"])
print("Без цены", missing["price"])
print("Полных повторов", raw.duplicated().sum())
