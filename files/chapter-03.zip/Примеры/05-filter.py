import pandas as pd

table = pd.read_csv("delivery.csv")
mask = table["service"] == "express"
columns = ["order_id", "service"]
express = table.loc[mask, columns]

print("Число строк", len(express))
print("Первые заказы", express["order_id"].head(3).tolist())
