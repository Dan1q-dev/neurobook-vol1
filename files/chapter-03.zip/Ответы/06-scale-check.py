import pandas as pd

raw = pd.read_csv("delivery.csv")
labelled = raw.drop_duplicates().dropna(subset=["price"])
train = labelled.loc[labelled["split"] == "train"]
train_distance = train["distance_km"]
all_distance = labelled["distance_km"]
distance = 3

def scale(value, numbers):
    low = numbers.min()
    high = numbers.max()
    return (value - low) / (high - low)

print("По train", round(scale(distance, train_distance), 4))
print("По всем строкам", round(scale(distance, all_distance), 4))
