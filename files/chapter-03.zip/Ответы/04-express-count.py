import pandas as pd

raw = pd.read_csv("delivery.csv")
clean = raw.drop_duplicates()
labelled = clean.dropna(subset=["price"])

print("В исходной", (raw["service"] == "express").sum())
print("Без повторов", (clean["service"] == "express").sum())
print("С ценами", (labelled["service"] == "express").sum())
