import numpy as np

features = np.array([[1, 1], [2, 2], [4, 3]])
weights = features[:, 1]

print("Весь массив", features.shape)
print("Столбец", weights.shape)
print("Массы", weights.tolist())
print("Средняя масса", weights.mean())
