import pandas as pd

raw = pd.read_csv("delivery.csv")
raw.loc[raw["order_id"] == 108, "weight_kg"] = 0.25
labelled = raw.drop_duplicates().dropna(subset=["price"])
train = labelled.loc[labelled["split"] == "train"]
test = labelled.loc[labelled["split"] == "test"]

median = train["weight_kg"].median()
filled = test["weight_kg"].fillna(median)
print("Медиана train", median)
print("Масса 109", filled.loc[test["order_id"] == 109].tolist())
print("Общая медиана", labelled["weight_kg"].median())
