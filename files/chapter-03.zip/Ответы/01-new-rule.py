import numpy as np

distances = np.array([1, 2, 4, 5])
actual = np.array([5, 8, 14, 17])
w = 4
b = 0
predictions = w * distances + b
errors = np.abs(predictions - actual)

print("Предсказания", predictions.tolist())
print("Ошибки", errors.tolist())
print("MAE", errors.mean())
