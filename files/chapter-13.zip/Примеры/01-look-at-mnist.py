import torch
from torchvision.datasets import MNIST
from torchvision.transforms import ToTensor

images = MNIST("data", train=True, transform=ToTensor(), download=True)
X, y = images[0]
counts = torch.bincount(images.targets, minlength=10)
print("В исходной обучающей части", len(images))
print("Первая метка", y)
print("Изображение", tuple(X.shape), X.dtype)
print(f"Диапазон от {X.min().item():.1f} до {X.max().item():.1f}")
print("Число примеров по классам", counts.tolist())
