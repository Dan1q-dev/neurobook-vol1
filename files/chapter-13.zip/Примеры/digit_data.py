import torch
from torch.utils.data import DataLoader, random_split
from torchvision.datasets import MNIST
from torchvision.transforms import ToTensor

def load_digits(train):
    return MNIST("data", train=train, transform=ToTensor(), download=True)

def training_sets():
    original = load_digits(train=True)
    split_rng = torch.Generator().manual_seed(17)
    return random_split(original, [54000, 6000], generator=split_rng)

def batches(dataset, shuffle=False):
    rng = torch.Generator().manual_seed(19) if shuffle else None
    return DataLoader(dataset, batch_size=128, shuffle=shuffle, generator=rng)

if __name__ == "__main__":
    train, val = training_sets()
    loader = batches(train, shuffle=True)
    X, y = next(iter(loader))
    print("Обучение", len(train), "валидация", len(val))
    print("Форма пакета", tuple(X.shape))
    print("Метки", tuple(y.shape), y.dtype)
    print("Пакетов за эпоху", len(loader))
