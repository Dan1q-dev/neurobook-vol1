import torch
from torch import nn

CHECKPOINT = "mnist-cnn.pt"

def make_model():
    return nn.Sequential(
        nn.Conv2d(1, 8, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
        nn.Conv2d(8, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
        nn.Flatten(), nn.Linear(16 * 7 * 7, 10),
    )

def load_model():
    saved = torch.load(CHECKPOINT, map_location="cpu", weights_only=True)
    model = make_model()
    model.load_state_dict(saved["state_dict"])
    model.eval()
    return model, saved["epoch"]

if __name__ == "__main__":
    model = make_model()
    X = torch.zeros(2, 1, 28, 28)
    with torch.inference_mode():
        first = model[:3](X)
        second = model[3:6](first)
        logits = model[6:](second)
    print("После первого пулинга", tuple(first.shape))
    print("После второго пулинга", tuple(second.shape))
    print("Логиты", tuple(logits.shape))
    print("Параметров", sum(p.numel() for p in model.parameters()))
