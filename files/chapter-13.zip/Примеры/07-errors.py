import json
from pathlib import Path

report = json.loads(Path("mnist-test.json").read_text(encoding="utf-8"))
table = report["confusion"]
recall = [table[d][d] / sum(table[d]) for d in range(10)]
worst = min(range(10), key=lambda d: recall[d])
pairs = [(i, j) for i in range(10) for j in range(10) if i != j]
actual, predicted = max(pairs, key=lambda pair: table[pair[0]][pair[1]])
print("Полнота от 0 до 9, %", [round(100 * r, 2) for r in recall])
print(f"Минимум у класса {worst}, {100 * recall[worst]:.2f}%")
print(f"Чаще всего путали {actual} с {predicted}, "
      f"таких ошибок {table[actual][predicted]}")
