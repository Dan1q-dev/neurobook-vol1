import torch
from torch import nn

def measure(model, loader):
    model.eval()
    criterion = nn.CrossEntropyLoss(reduction="sum")
    total_loss = 0.0
    labels, predictions = [], []
    with torch.inference_mode():
        for X, y in loader:
            logits = model(X)
            total_loss += criterion(logits, y).item()
            labels.append(y)
            predictions.append(logits.argmax(dim=1))
    y = torch.cat(labels)
    pred = torch.cat(predictions)
    return total_loss / len(y), y, pred

def confusion(labels, predictions):
    indices = 10 * labels + predictions
    return torch.bincount(indices, minlength=100).reshape(10, 10)

if __name__ == "__main__":
    labels = torch.tensor([0, 0, 1, 1, 2, 2])
    predictions = torch.tensor([0, 1, 1, 2, 2, 2])
    table = confusion(labels, predictions)
    for row in table[:3, :3].tolist():
        print(row)
    correct = table.diag().sum().item()
    accuracy = correct / table.sum().item()
    print(f"Точность {accuracy:.4f}")
