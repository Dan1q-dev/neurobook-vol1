import json
from pathlib import Path
import torch
from digit_data import batches, load_digits
from digit_metrics import confusion, measure
from digit_model import load_model

torch.set_num_threads(4)
model, epoch = load_model()
test = load_digits(train=False)
loss, y, pred = measure(model, batches(test))
table = confusion(y, pred)
correct = table.diag().sum().item()
wrong = (y != pred).nonzero(as_tuple=True)[0].tolist()
errors = [[i, y[i].item(), pred[i].item()] for i in wrong]
report = {"epoch": epoch, "examples": len(test), "loss": loss,
          "correct": correct, "confusion": table.tolist(), "errors": errors}
path = Path("mnist-test.json")
temporary = path.with_suffix(".tmp")
temporary.write_text(json.dumps(report, indent=2), encoding="utf-8")
temporary.replace(path)
print(f"Эпоха {epoch}, тестовая потеря {loss:.4f}")
print(f"Верно {correct}/{len(test)}, точность {100 * correct / len(test):.2f}%")
print("Записан", path.name)
