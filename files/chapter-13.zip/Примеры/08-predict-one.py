import json
from pathlib import Path
import torch
from digit_data import load_digits
from digit_model import load_model

torch.set_num_threads(4)
report = json.loads(Path("mnist-test.json").read_text(encoding="utf-8"))
index = report["errors"][0][0] if report["errors"] else 0
model, _ = load_model()
image, label = load_digits(train=False)[index]
with torch.inference_mode():
    logits = model(image.unsqueeze(0))
    probs = logits.softmax(dim=1)[0]
    probabilities, digits = probs.topk(3)
print(f"Номер {index}, метка {label}, прогноз {digits[0].item()}")
for digit, probability in zip(digits.tolist(), probabilities.tolist()):
    print(f"Цифра {digit}, softmax {probability:.4f}")
