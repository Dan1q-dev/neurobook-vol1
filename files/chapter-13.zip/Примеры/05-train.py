from pathlib import Path
import torch
from torch import nn
from digit_data import batches, training_sets
from digit_metrics import measure
from digit_model import CHECKPOINT, make_model

torch.set_num_threads(4)
torch.manual_seed(41)
train, val = training_sets()
train_loader, val_loader = batches(train, shuffle=True), batches(val)
model = make_model()
criterion = nn.CrossEntropyLoss()
opt = torch.optim.Adam(model.parameters(), lr=0.001)
best_loss = float("inf")

for epoch in range(1, 4):
    model.train()
    train_sum = 0.0
    for X, y in train_loader:
        opt.zero_grad()
        loss = criterion(model(X), y)
        loss.backward()
        opt.step()
        train_sum += loss.item() * len(y)
    val_loss, expected, pred = measure(model, val_loader)
    correct = (expected == pred).sum().item()
    print(f"Эпоха {epoch}, train {train_sum / len(train):.4f}, "
          f"val {val_loss:.4f}, верно {correct}/{len(expected)}", flush=True)
    if val_loss < best_loss:
        best_loss, best_epoch = val_loss, epoch
        temporary = Path(CHECKPOINT).with_suffix(".tmp")
        torch.save({"epoch": epoch, "state_dict": model.state_dict()}, temporary)
        temporary.replace(CHECKPOINT)
print(f"Сохранена эпоха {best_epoch}")
