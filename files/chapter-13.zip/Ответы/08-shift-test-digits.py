from pathlib import Path
import sys
import torch
from torchvision.transforms.functional import to_pil_image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "Примеры"))
from digit_data import load_digits
from digit_model import load_model

torch.set_num_threads(4)
test = load_digits(train=False)
X = torch.stack([test[i][0] for i in range(256)])
y = test.targets[:256]
shift = 4
shifted = torch.zeros_like(X)
if shift > 0:
    shifted[:, :, :, shift:] = X[:, :, :, :-shift]
elif shift < 0:
    shifted[:, :, :, :shift] = X[:, :, :, -shift:]
else:
    shifted = X.clone()

model, _ = load_model()
with torch.inference_mode():
    before = model(X).argmax(dim=1)
    after = model(shifted).argmax(dim=1)
for name, predictions in (("Исходные", before), ("Сдвинутые", after)):
    correct = (predictions == y).sum().item()
    print(f"{name}: {correct}/{len(y)}, {100 * correct / len(y):.2f}%")

changed = (before != after).nonzero(as_tuple=True)[0]
if changed.numel():
    i = changed[0].item()
    print(f"Индекс {i}, метка {y[i]}, прогнозы {before[i]} и {after[i]}")
    to_pil_image(X[i]).save("цифра-до.png")
    to_pil_image(shifted[i]).save("цифра-после.png")
else:
    print("Прогнозы совпадают")
