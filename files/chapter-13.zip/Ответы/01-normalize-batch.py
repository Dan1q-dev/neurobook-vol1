import torch

pixels = torch.tensor([0, 128, 255], dtype=torch.uint8)
normalized = pixels.float() / 255
images = torch.zeros(2, 1, 28, 28)
images[0, 0, 0, :3] = normalized
print("Яркости", [round(value, 6) for value in normalized.tolist()])
print("Форма пакета", tuple(images.shape))
print("Пикселей в пакете", images.numel())
