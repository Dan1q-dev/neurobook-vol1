from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "Примеры"))
from digit_data import training_sets

train, val = training_sets()
first, second = set(train.indices), set(val.indices)
repeated, _ = training_sets()
print("Размеры", len(first), len(second))
print("Пересечение", len(first & second))
print("Все исходные индексы покрыты", first | second == set(range(60000)))
print("Порядок воспроизведён", train.indices == repeated.indices)
