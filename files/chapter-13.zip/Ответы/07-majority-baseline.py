import json
from pathlib import Path
import sys
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "Примеры"))
from digit_data import training_sets

train, _ = training_sets()
counts = torch.bincount(train.dataset.targets[train.indices], minlength=10)
majority = counts.argmax().item()
result = json.loads(Path("mnist-test.json").read_text(encoding="utf-8"))
baseline = sum(result["confusion"][majority])
total = result["examples"]
print("Частый класс в train", majority, "картинок", counts[majority].item())
print(f"Базовая точность {baseline}/{total} = {100 * baseline / total:.2f}%")
print(f"Разница {100 * (result['correct'] - baseline) / total:.2f} п. п.")
