from math import exp, log
import torch
from torch import nn

logits = torch.tensor([[2.0] + [0.0] * 9], dtype=torch.float64)
target = torch.tensor([0])
manual = exp(2) / (exp(2) + 9)
criterion = nn.CrossEntropyLoss()
loss = criterion(logits, target).item()
print(f"По формуле {manual:.6f}")
print(f"Softmax {logits.softmax(1)[0, 0].item():.6f}")
print(f"Потеря вручную {-log(manual):.6f}, в PyTorch {loss:.6f}")
