full, last = divmod(54000, 128)
sizes = [2, 1]
losses = [0.2, 0.8]
total = sum(size * loss for size, loss in zip(sizes, losses))
print("Полных пакетов", full, "последний размер", last)
print("Шагов", full + int(last > 0))
print(f"Потеря по объектам {total / sum(sizes):.3f}")
print(f"Среднее по пакетам {sum(losses) / len(losses):.3f}")
