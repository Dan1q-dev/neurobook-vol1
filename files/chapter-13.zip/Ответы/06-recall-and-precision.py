import json
from pathlib import Path

table = json.loads(Path("mnist-test.json").read_text(encoding="utf-8"))["confusion"]
digit = 7
true_positive = table[digit][digit]
actual = sum(table[digit])
predicted = sum(row[digit] for row in table)
print("Верные семёрки", true_positive)
print("Настоящих семёрок", actual, "прогнозов семёрки", predicted)
print(f"Полнота {100 * true_positive / actual:.2f}%")
print(f"Точность класса {100 * true_positive / predicted:.2f}%")
