from pathlib import Path
import sys
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "Примеры"))
from digit_model import make_model

model = make_model()
X = torch.zeros(3, 1, 28, 28)
with torch.inference_mode():
    hidden = model[:6](X)
    logits = model[6:](hidden)
print("После пулинга", tuple(hidden.shape))
print("После Flatten", tuple(hidden.flatten(1).shape))
print("Логиты", tuple(logits.shape))
for index in (0, 3, 7):
    count = sum(p.numel() for p in model[index].parameters())
    print(f"Слой {index}, параметров {count}")
