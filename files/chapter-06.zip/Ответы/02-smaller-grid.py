from statistics import mean

required = [2, 3, 2]
for b in (2, 2.25, 2.50, mean(required)):
    loss = mean((b - value) ** 2 for value in required)
    print(f"b {b:.3f}, MSE {loss:.6f}")
