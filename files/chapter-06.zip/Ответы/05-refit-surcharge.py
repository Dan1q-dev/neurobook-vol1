from sklearn.linear_model import LinearRegression

X = [[1, 0], [3, 0], [1, 1], [3, 1]]
y = [5, 11, 10, 16]
model = LinearRegression().fit(X, y)
w, c = model.coef_
standard, express = model.predict([[4, 0], [4, 1]])
print(f"w {w:.3f}, c {c:.3f}, b {model.intercept_:.3f}")
print(f"На 4 км, обычная {standard:.3f}, срочная {express:.3f}")
