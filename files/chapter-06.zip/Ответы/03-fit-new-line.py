from statistics import mean

x = [1, 3, 5]
y = [4, 11, 13]
x_mean, y_mean = mean(x), mean(y)
dx = [value - x_mean for value in x]
dy = [value - y_mean for value in y]
product = sum(a * b for a, b in zip(dx, dy))
squares = sum(value ** 2 for value in dx)
w = product / squares
b = y_mean - w * x_mean

print(f"Средние {x_mean:.3f}, {y_mean:.3f}")
print(f"Суммы {product:.3f}, {squares:.3f}")
print(f"w {w:.3f}, b {b:.3f}, прогноз на 3 км {w * 3 + b:.3f}")
