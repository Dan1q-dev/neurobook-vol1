import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

orders = pd.read_csv("orders-quality.csv")
orders["is_express"] = (orders["service"] == "express").astype(int)
train = orders.loc[orders["day"] <= 10]
test = orders.loc[orders["day"] >= 15]
cols = ["distance_km", "is_express"]
model = LinearRegression().fit(train[cols], train["price"])
predicted = model.predict(test[cols])
new_price = test["price"].copy()
new_price.loc[test["order_id"] == 217] = 34

old = mean_absolute_error(test["price"], predicted)
new = mean_absolute_error(new_price, predicted)
print(f"MAE до изменения {old:.3f}")
print(f"MAE после изменения {new:.3f}")
print(f"Разница {new - old:.3f}")
