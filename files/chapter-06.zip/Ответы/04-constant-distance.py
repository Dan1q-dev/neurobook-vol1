from statistics import mean

x = [2, 2, 2]
y = [6, 8, 10]
x_mean = mean(x)
total_square = sum((value - x_mean) ** 2 for value in x)
print("Сумма квадратов dx", total_square)
print("Лучший прогноз при 2 км", mean(y))
for w, b in ((0, 8), (3, 2)):
    predicted = [w * value + b for value in x]
    mse = mean((a - b) ** 2 for a, b in zip(predicted, y))
    print("w, b", w, b, "прогнозы", predicted, f"MSE {mse:.3f}")
