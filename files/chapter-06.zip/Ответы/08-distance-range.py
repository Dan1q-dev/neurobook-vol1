from sklearn.linear_model import LinearRegression

distance = [1, 2, 3]
X = [[value] for value in distance]
model = LinearRegression().fit(X, [5, 9, 11])
for value in (2, 12):
    predicted = model.predict([[value]])[0]
    inside = min(distance) <= value <= max(distance)
    print(f"{value} км: {predicted:.3f}, внутри диапазона {inside}")
