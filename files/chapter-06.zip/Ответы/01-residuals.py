from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]
predicted = [2 * value + 3 for value in x]
errors = [a - b for a, b in zip(predicted, y)]
print("Прогнозы", predicted)
print("Ошибки", errors)
print(f"MAE {mean(abs(e) for e in errors):.3f}")
print(f"MSE {mean(e ** 2 for e in errors):.3f}")
