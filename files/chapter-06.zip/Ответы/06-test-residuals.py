import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

orders = pd.read_csv("orders-quality.csv")
orders["is_express"] = (orders["service"] == "express").astype(int)
train = orders.loc[orders["day"] <= 10]
test = orders.loc[orders["day"] >= 15]
cols = ["distance_km", "is_express"]
model = LinearRegression().fit(train[cols], train["price"])
predicted = model.predict(test[cols])

for order, fact, value in zip(test["order_id"], test["price"], predicted):
    print(f"{order} факт {fact}, прогноз {value:.3f}, ошибка {value-fact:.3f}")
print(f"MAE {mean_absolute_error(test['price'], predicted):.3f}")
