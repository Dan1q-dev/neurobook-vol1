from statistics import mean

def fit_line(x, y):
    if not x or len(x) != len(y):
        raise ValueError("Нужны пары расстояния и цены")
    x_mean, y_mean = mean(x), mean(y)
    dx = [value - x_mean for value in x]
    dy = [value - y_mean for value in y]
    total_square = sum(value ** 2 for value in dx)
    if total_square == 0:
        raise ValueError("Для веса нужны разные расстояния")
    total_product = sum(a * b for a, b in zip(dx, dy))
    w = total_product / total_square
    b = y_mean - w * x_mean
    return w, b

x = [1, 2, 3]
y = [5, 9, 11]
w, b = fit_line(x, y)
predicted = [w * value + b for value in x]
mse = mean((prediction - price) ** 2
           for prediction, price in zip(predicted, y))
print(f"w {w:.3f}, b {b:.3f}")
print("Прогнозы", [round(value, 3) for value in predicted])
print(f"MSE {mse:.6f}")
