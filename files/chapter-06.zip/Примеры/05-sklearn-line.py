import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

X = np.array([[1], [2], [3]])
y = np.array([5, 9, 11])
model = LinearRegression()
model.fit(X, y)
predicted = model.predict(X)
at_four = model.predict([[4]])[0]

print("Формы X и y", X.shape, y.shape)
print(f"w {model.coef_[0]:.3f}, b {model.intercept_:.3f}")
print(f"MSE train {mean_squared_error(y, predicted):.6f}")
print(f"Прогноз на 4 км {at_four:.3f}")
