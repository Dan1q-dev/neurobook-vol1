from sklearn.linear_model import LinearRegression

X = [[1, 0], [3, 0], [1, 1], [3, 1]]
y = [5, 11, 9, 15]
model = LinearRegression().fit(X, y)
w, c = model.coef_
b = model.intercept_
standard, express = model.predict([[2, 0], [2, 1]])

print(f"w {w:.3f}, c {c:.3f}, b {b:.3f}")
print(f"На 2 км, обычная {standard:.3f}, срочная {express:.3f}")
