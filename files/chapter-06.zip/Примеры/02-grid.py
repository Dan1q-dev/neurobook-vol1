distance = [1, 2, 3]
actual = [5, 9, 11]
best_loss = float("inf")
best_pair = None

for w in (2, 3, 4):
    for b in (1, 2, 3):
        squared = [(w * x + b - y) ** 2
                   for x, y in zip(distance, actual)]
        loss = sum(squared) / len(squared)
        if loss < best_loss:
            best_loss = loss
            best_pair = (w, b)

print("Лучшие w и b", best_pair)
print(f"MSE {best_loss:.6f}")
