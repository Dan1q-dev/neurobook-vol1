from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]
w = 3
required = [price - w * distance for distance, price in zip(x, y)]
best_b = mean(required)

print("Требуемые смещения", required)
for b in (2, best_b, 3):
    loss = mean((b - value) ** 2 for value in required)
    print(f"b {b:.3f}, MSE {loss:.6f}")
