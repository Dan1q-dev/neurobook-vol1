from sklearn.linear_model import LinearRegression

X = [[1], [2], [3]]
for label, y in (
    ("Исходные цены", [5, 9, 11]),
    ("Изменённая цена", [5, 9, 20]),
):
    model = LinearRegression().fit(X, y)
    w = model.coef_[0]
    b = model.intercept_
    at_four = model.predict([[4]])[0]
    print(f"{label}: w {w:.3f}, b {b:.3f}, прогноз {at_four:.3f}")
