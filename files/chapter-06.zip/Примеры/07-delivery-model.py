import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

orders = pd.read_csv("orders-quality.csv")
if not orders["service"].isin(["standard", "express"]).all():
    raise ValueError("Проверьте типы доставки")
orders["is_express"] = (orders["service"] == "express").astype(int)
day = orders["day"]
train = orders.loc[day <= 10]
val = orders.loc[day.between(11, 14)]
test = orders.loc[day >= 15]
if train.empty or val.empty or test.empty:
    raise ValueError("Проверьте даты трёх выборок")

variants = {"Расстояние": ["distance_km"],
            "Расстояние и тип": ["distance_km", "is_express"]}
models = {}
scores = {}
for name, columns in variants.items():
    reg = LinearRegression().fit(train[columns], train["price"])
    models[name] = reg
    scores[name] = mean_absolute_error(
        val["price"], reg.predict(val[columns])
    )
    print(f"MAE val / {name} {scores[name]:.3f}")

chosen = min(scores, key=scores.get)
model = models[chosen]
predicted = model.predict(test[variants[chosen]])
baseline = [train["price"].median()] * len(test)
actual = test["price"]
print("Выбрано", chosen)
print(f"Веса {model.coef_.round(3).tolist()}, b {model.intercept_:.3f}")
print(f"MAE test / модель {mean_absolute_error(actual, predicted):.3f}")
print(f"MAE test / медиана {mean_absolute_error(actual, baseline):.3f}")
