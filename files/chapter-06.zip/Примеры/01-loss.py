distance = [1, 2, 3]
actual = [5, 9, 11]

for w, b in ((3, 2), (2, 2)):
    predicted = [w * x + b for x in distance]
    errors = [p - y for p, y in zip(predicted, actual)]
    squares = [error ** 2 for error in errors]
    loss = sum(squares) / len(squares)
    print("w, b", w, b)
    print("Прогнозы", predicted, "ошибки", errors)
    print(f"MSE {loss:.3f}")
