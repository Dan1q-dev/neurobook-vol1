from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]
for rate in (0.10, 0.25):
    w, b = 2.0, 2.0
    for step in range(1, 13):
        e = [w * a + b - price for a, price in zip(x, y)]
        dw = 2 * mean(error * a for error, a in zip(e, x))
        db = 2 * mean(e)
        w, b = w - rate * dw, b - rate * db
        if step in (1, 12):
            loss = mean((w * a + b - price) ** 2
                        for a, price in zip(x, y))
            print(f"η {rate:.2f}, шаг {step}, MSE {loss:.6f}")
