from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]
dw, db = -32 / 3, -14 / 3
rate = 0.1
for name, sign in (("Плюс", 1), ("Минус", -1)):
    w = 2 + sign * rate * dw
    b = 2 + sign * rate * db
    loss = mean((w * a + b - price) ** 2 for a, price in zip(x, y))
    print(f"{name}: w {w:.6f}, b {b:.6f}, MSE {loss:.6f}")
