from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]
w, b = 2.0, 2.0
e = [w * a + b - price for a, price in zip(x, y)]
dw = 2 * mean(error * a for error, a in zip(e, x))
db = 2 * mean(e)
w, b = w - 0.05 * dw, b - 0.05 * db
after = mean((w * a + b - price) ** 2 for a, price in zip(x, y))
print(f"dw {dw:.6f}, db {db:.6f}")
print(f"w {w:.6f}, b {b:.6f}, MSE {after:.6f}")
