distance, urgent, price = 2, 1, 11
w, c, b = 3.0, 0.0, 2.0
rate = 0.05
predicted = w * distance + c * urgent + b
e = predicted - price
dw, dc, db = 2 * e * distance, 2 * e * urgent, 2 * e
w, c, b = w - rate * dw, c - rate * dc, b - rate * db
new_prediction = w * distance + c * urgent + b
print(f"Градиент {dw:.1f}, {dc:.1f}, {db:.1f}")
print(f"Параметры {w:.1f}, {c:.1f}, {b:.1f}")
print(f"Прогноз {new_prediction:.1f}")
print(f"Потеря {(new_prediction - price) ** 2:.2f}")
