from statistics import mean

def loss(b):
    return mean((b - a) ** 2 for a in [2, 3, 2])

for rate in (0.5, 1.0):
    b = 2.0
    for step in (1, 2):
        db = 2 * (b - 7 / 3)
        b = b - rate * db
        print(f"η {rate:.1f}, шаг {step}, b {b:.6f}, MSE {loss(b):.6f}")
