from statistics import mean

def loss(w, b):
    return mean((w * x + b - y) ** 2
                for x, y in zip([1, 2, 3], [5, 9, 11]))

w, b, h = 3.0, 2.0, 0.0001
dw = (loss(w + h, b) - loss(w - h, b)) / (2 * h)
db = (loss(w, b + h) - loss(w, b - h)) / (2 * h)
print(f"Численно dw {dw:.6f}, db {db:.6f}")
print(f"По формуле dw {-4 / 3:.6f}, db {-2 / 3:.6f}")
