from statistics import mean

def loss(b):
    return mean((b - a) ** 2 for a in [2, 3, 2])

b = 3
for h in (0.1, 0.01):
    slope = (loss(b + h) - loss(b)) / h
    print(f"h {h:.2f}, наклон {slope:.6f}")
print(f"Производная {2 * (b - 7 / 3):.6f}")
