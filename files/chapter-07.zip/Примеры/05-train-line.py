from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]

def residuals(w, b):
    return [w * a + b - price for a, price in zip(x, y)]

def report(step, w, b):
    loss = mean(e ** 2 for e in residuals(w, b))
    print(f"{step}: w {w:.6f}, b {b:.6f}, MSE {loss:.6f}")

w, b = 2.0, 2.0
rate = 0.1
report(0, w, b)
for step in range(1, 501):
    errors = residuals(w, b)
    dw = 2 * mean(e * a for e, a in zip(errors, x))
    db = 2 * mean(errors)
    w, b = w - rate * dw, b - rate * db
    if step in (1, 2, 5, 20, 500):
        report(step, w, b)
