from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]

def losses(rate, steps):
    w, b = 2.0, 2.0
    history = []
    for step in range(steps + 1):
        e = [w * a + b - price for a, price in zip(x, y)]
        history.append(mean(value ** 2 for value in e))
        if step < steps:
            dw = 2 * mean(value * a for value, a in zip(e, x))
            db = 2 * mean(e)
            w, b = w - rate * dw, b - rate * db
    return history

for rate in (0.01, 0.10, 0.20):
    history = losses(rate, 12)
    print(f"η {rate:.2f}: шаг 1 {history[1]:.6f}, шаг 12 {history[12]:.6f}")
