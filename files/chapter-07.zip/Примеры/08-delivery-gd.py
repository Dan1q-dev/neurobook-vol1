import numpy as np
import pandas as pd

orders = pd.read_csv("orders-quality.csv")
if not orders["service"].isin(["standard", "express"]).all():
    raise ValueError("Проверьте типы доставки")
day = orders["day"]
train = orders.loc[day <= 10]
val = orders.loc[day.between(11, 14)]
test = orders.loc[day >= 15]
if train.empty or val.empty or test.empty:
    raise ValueError("Проверьте границы выборок")
distance = train["distance_km"]
center, scale = distance.mean(), distance.std(ddof=0)
if not scale > 0:
    raise ValueError("Для масштаба нужны разные расстояния")

def features(rows):
    distance = (rows["distance_km"] - center) / scale
    urgent = (rows["service"] == "express").astype(int)
    return np.column_stack([distance, urgent])

X = features(train)
y = train["price"].to_numpy()
w = np.zeros(X.shape[1])
b, rate = 0.0, 0.1
for _ in range(500):
    e = X @ w + b - y
    dw = 2 * (X.T @ e) / len(y)
    db = 2 * e.mean()
    w, b = w - rate * dw, b - rate * db

per_km = w[0] / scale
base = b - center * per_km
print(f"MSE train до {(y ** 2).mean():.3f}")
print(f"MSE train после {((X @ w + b - y) ** 2).mean():.3f}")
print(f"w за км {per_km:.3f}, вес срочности {w[1]:.3f}, b {base:.3f}")
for label, rows in (("validation", val), ("test", test)):
    e = features(rows) @ w + b - rows["price"].to_numpy()
    print(f"MAE {label} {np.abs(e).mean():.3f}")
