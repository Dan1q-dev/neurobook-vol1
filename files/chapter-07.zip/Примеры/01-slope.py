from statistics import mean

def loss(b):
    return mean((b - value) ** 2 for value in [2, 3, 2])

b = 2
print(f"L(b) {loss(b):.6f}")
for h in (0.1, 0.01, 0.001):
    slope = (loss(b + h) - loss(b)) / h
    print(f"h {h:.3f}, наклон {slope:.6f}")
