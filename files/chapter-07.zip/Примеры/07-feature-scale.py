from statistics import mean

y = [5, 9, 11]
for unit, x, w in (
    ("км", [1, 2, 3], 2),
    ("м", [1000, 2000, 3000], 0.002),
):
    predicted = [w * a + 2 for a in x]
    errors = [p - price for p, price in zip(predicted, y)]
    dw = 2 * mean(e * a for e, a in zip(errors, x))
    db = 2 * mean(errors)
    print(unit, "прогнозы", [round(value) for value in predicted])
    print(f"dw {dw:.3f}, db {db:.3f}")
