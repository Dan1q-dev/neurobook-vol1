from statistics import mean

required = [2, 3, 2]
b = 2
rate = 0.25
before = mean((b - value) ** 2 for value in required)
db = 2 * mean(b - value for value in required)
new_b = b - rate * db
after = mean((new_b - value) ** 2 for value in required)

print(f"Производная {db:.6f}")
print(f"До шага: b {b:.6f}, MSE {before:.6f}")
print(f"После шага: b {new_b:.6f}, MSE {after:.6f}")
