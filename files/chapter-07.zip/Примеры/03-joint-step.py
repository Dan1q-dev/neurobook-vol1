from statistics import mean

x = [1, 2, 3]
y = [5, 9, 11]
w, b = 2.0, 2.0
rate = 0.1

errors = [w * a + b - price for a, price in zip(x, y)]
dw = 2 * mean(e * a for e, a in zip(errors, x))
db = 2 * mean(errors)
new_w, new_b = w - rate * dw, b - rate * db
new_errors = [new_w * a + new_b - price for a, price in zip(x, y)]

print(f"dw {dw:.6f}, db {db:.6f}")
print(f"После шага w {new_w:.6f}, b {new_b:.6f}")
print(f"MSE до {mean(e ** 2 for e in errors):.6f}")
print(f"MSE после {mean(e ** 2 for e in new_errors):.6f}")
