from statistics import mean

def loss(w, b):
    x = [1, 2, 3]
    y = [5, 9, 11]
    return mean((w * a + b - price) ** 2 for a, price in zip(x, y))

w, b = 2.0, 2.0
h = 0.0001
dw = (loss(w + h, b) - loss(w - h, b)) / (2 * h)
db = (loss(w, b + h) - loss(w, b - h)) / (2 * h)
print(f"Численно dw {dw:.6f}, db {db:.6f}")
print(f"По формуле dw {-32 / 3:.6f}, db {-14 / 3:.6f}")
