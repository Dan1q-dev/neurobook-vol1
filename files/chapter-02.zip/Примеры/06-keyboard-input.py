text = input("Расстояние в км: ")
distance = float(text)
price = 3 * distance + 2
print("Стоимость:", price)
