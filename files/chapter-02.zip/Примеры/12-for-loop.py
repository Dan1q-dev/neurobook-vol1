distances = [1, 2, 4, 5]

for distance in distances:
    price = 3 * distance + 2
    print(distance, price)
