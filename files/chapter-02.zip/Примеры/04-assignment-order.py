distance = 4
price = 3 * distance + 2
print(price)

distance = 6
print(price)

price = 3 * distance + 2
print(price)
