actual = 5
prediction = 3
difference = prediction - actual
error = abs(difference)
print("Разность:", difference)
print("Абсолютная ошибка:", error)
