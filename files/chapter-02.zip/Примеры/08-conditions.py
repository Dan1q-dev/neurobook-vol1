distance = -2

if distance < 0:
    print("Расстояние не может быть отрицательным.")
else:
    price = 3 * distance + 2
    print("Стоимость:", price)
