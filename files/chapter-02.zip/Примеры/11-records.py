samples = [[1, 5], [2, 8], [4, 14], [5, 17]]
print(samples[0])
print(samples[0][0])
print(samples[0][1])
