distance = 4
w = 3
b = 2
price = w * distance + b
print("Стоимость:", price)
