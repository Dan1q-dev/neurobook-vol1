distance = 4
print(distnace)
