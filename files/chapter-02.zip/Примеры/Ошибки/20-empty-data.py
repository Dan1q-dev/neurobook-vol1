samples = []

if len(samples) == 0:
    raise ValueError("Нужна хотя бы одна запись.")
