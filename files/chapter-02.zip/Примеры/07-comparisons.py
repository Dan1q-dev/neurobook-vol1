distance = 4
print(distance >= 0)
print(distance < 0)
print(distance == 4)
print(distance != 4)
