from math import isfinite

text = input("Расстояние в км: ")

try:
    distance = float(text)
except ValueError:
    print("Введите число через точку, например 3.5.")
else:
    if not isfinite(distance):
        print("Нужно конечное число, например 3.5.")
    elif distance < 0:
        print("Расстояние не может быть отрицательным.")
    else:
        price = 3 * distance + 2
        print("Стоимость:", price)
