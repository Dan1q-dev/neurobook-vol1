actual = 8
prediction = 7

if prediction < actual:
    print("Предсказание ниже ответа.")
elif prediction == actual:
    print("Предсказание совпадает с ответом.")
else:
    print("Предсказание выше ответа.")
