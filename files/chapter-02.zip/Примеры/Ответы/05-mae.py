actuals = [5, 8, 14, 17]
predictions = [3, 5, 9, 11]
errors = []
total_error = 0

for index in range(len(actuals)):
    error = abs(predictions[index] - actuals[index])
    errors.append(error)
    total_error = total_error + error

mae = total_error / len(actuals)
print("Ошибки:", errors)
print("MAE:", mae)
