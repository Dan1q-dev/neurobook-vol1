train = [[1, 5], [2, 8], [4, 14], [5, 17]]
test = [[3, 11], [6, 20]]

total_price = 0
for sample in train:
    total_price = total_price + sample[1]
baseline = total_price / len(train)

total_error = 0
for sample in test:
    actual = sample[1]
    total_error = total_error + abs(baseline - actual)

test_mae = total_error / len(test)
print("Постоянное предсказание:", baseline)
print("MAE на новых данных:", test_mae)
