prices = [5, 8, 14, 17]
print(prices[0])
print(prices[-1])
print(len(prices))
print(sum(prices) / len(prices))
