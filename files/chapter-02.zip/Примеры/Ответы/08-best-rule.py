def predict(distance, w, b):
    return w * distance + b


def mae(samples, w, b):
    if len(samples) == 0:
        raise ValueError("Нужна хотя бы одна запись.")
    total_error = 0
    for sample in samples:
        prediction = predict(sample[0], w, b)
        total_error = total_error + abs(prediction - sample[1])
    return total_error / len(samples)


train = [[1, 5], [2, 8], [4, 14], [5, 17]]
candidates = [[2, 1], [4, 0], [3, 2]]

best_w = candidates[0][0]
best_b = candidates[0][1]
best_error = mae(train, best_w, best_b)

for candidate in candidates:
    w = candidate[0]
    b = candidate[1]
    error = mae(train, w, b)
    if error < best_error:
        best_w = w
        best_b = b
        best_error = error

test = [[3, 11], [6, 20]]
test_error = mae(test, best_w, best_b)
print("w =", best_w, "b =", best_b)
print("MAE на train:", best_error)
print("MAE на test:", test_error)
