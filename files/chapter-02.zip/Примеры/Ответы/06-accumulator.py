prices = [5, 8, 14, 17]
total = 0

for price in prices:
    total = total + price

mean_price = total / len(prices)
print(mean_price)
