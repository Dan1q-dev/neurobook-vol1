print(3 + 2)
print("3" + "2")
print(float("3.5") + 2)
