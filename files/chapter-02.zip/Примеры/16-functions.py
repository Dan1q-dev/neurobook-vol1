def predict(distance, w, b):
    return w * distance + b


first_price = predict(4, 3, 2)
second_price = predict(6, 3, 2)
print(first_price)
print(second_price)
