errors = [2, 3, 5, 6]
total = 0

for error in errors:
    total = total + error

mae = total / len(errors)
print("Сумма ошибок:", total)
print("MAE:", mae)
