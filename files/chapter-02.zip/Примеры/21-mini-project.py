def predict(distance, w, b):
    return w * distance + b


def mae(samples, w, b):
    if len(samples) == 0:
        raise ValueError("Нужна хотя бы одна запись.")

    total_error = 0
    for sample in samples:
        distance = sample[0]
        actual = sample[1]
        prediction = predict(distance, w, b)
        total_error = total_error + abs(prediction - actual)
    return total_error / len(samples)


train = [[1, 5], [2, 8], [4, 14], [5, 17]]
candidates = [[2, 1], [4, 0], [3, 2]]

for candidate in candidates:
    w = candidate[0]
    b = candidate[1]
    error = mae(train, w, b)
    print("w =", w, "b =", b, "MAE =", error)

selected_w = 3
selected_b = 2
test = [[3, 11], [6, 20]]
test_error = mae(test, selected_w, selected_b)
print("MAE на новых данных:", test_error)
