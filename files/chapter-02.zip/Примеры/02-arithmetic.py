print(7 / 2)
print(2 ** 3)
print((3 + 2) * 4)
print(3.5 * 2)
