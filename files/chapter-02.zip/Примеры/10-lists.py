distances = [1, 2, 4, 5]
print(distances)
print(distances[0])
print(distances[-1])
print(len(distances))

distances.append(6)
print(distances)
