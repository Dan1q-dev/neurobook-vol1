def predict(distance, w, b):
    return w * distance + b


def mae(samples, w, b):
    total_error = 0
    for sample in samples:
        distance = sample[0]
        actual = sample[1]
        prediction = predict(distance, w, b)
        total_error = total_error + abs(prediction - actual)
    return total_error / len(samples)


samples = [[1, 5], [2, 8], [4, 14], [5, 17]]
print(mae(samples, 2, 1))
print(mae(samples, 3, 2))
