distance = input("Расстояние в км: ")
price = 3 * distance + 2
print(price)
