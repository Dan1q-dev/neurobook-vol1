prices = [5, 8, 14, 17]

for price in prices:
    total = 0
    total = total + price

mean_price = total / len(prices)
print(mean_price)
