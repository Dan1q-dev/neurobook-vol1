distance = 4
price = 3 * distance + 2
distance = 7
print(price)
print(3 * distance + 2)
