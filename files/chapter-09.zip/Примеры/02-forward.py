from math import exp, log

x, y = [2, 1], 1
hidden_weights = ([0.5, 1], [-0.5, -0.5])
bias = (-1, 0.5)
s = []
for weights, offset in zip(hidden_weights, bias):
    s.append(sum(a * w for a, w in zip(x, weights)) + offset)
h = [max(0, value) for value in s]
z = h[0] - h[1] - 1
p = 1 / (1 + exp(-z))
loss = -log(p if y == 1 else 1 - p)

print("Суммы", s)
print("Активации", h)
print(f"z {z:.6f}, p {p:.6f}, потеря {loss:.6f}")
