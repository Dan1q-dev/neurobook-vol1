import numpy as np

x = np.array([2.0, 1.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b = np.array([-1.0, 0.5])
v = np.array([1.0, -1.0])
c, y = -1.0, 1

s = x @ W + b
h = np.maximum(s, 0)
z = h @ v + c
p = 1 / (1 + np.exp(-z))
dz = p - y

dv = h * dz
dc = dz
dh = v * dz
ds = np.where(s > 0, dh, 0.0)
dW = np.outer(x, ds)
db = ds
print("dz", dz)
print("dv", (dv + 0.0).tolist(), "dc", dc)
print("dh", dh.tolist(), "ds", ds.tolist())
print("dW", dW.tolist())
print("db", db.tolist())
