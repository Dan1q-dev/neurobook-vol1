import numpy as np

def forward(x, W, b, v, c):
    s = x @ W + b
    h = np.maximum(s, 0)
    return s, h, h @ v + c

x = np.array([2.0, 1.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
c, y, rate = -1.0, 1, 0.1
s, h, z = forward(x, W, b, v, c)
p = 1 / (1 + np.exp(-z))
before = np.logaddexp(0, (1 - 2 * y) * z)

dz = p - y
ds = np.where(s > 0, v * dz, 0.0)
dW, db = np.outer(x, ds), ds
dv, dc = h * dz, dz
W, b = W - rate * dW, b - rate * db
v, c = v - rate * dv, c - rate * dc

_, _, new_z = forward(x, W, b, v, c)
new_p = 1 / (1 + np.exp(-new_z))
after = np.logaddexp(0, (1 - 2 * y) * new_z)
print("W", W.round(2).tolist())
print("b", b.round(2).tolist(), "v", v.round(2).tolist(), f"c {c:.2f}")
print(f"До p {p:.6f}, потеря {before:.6f}")
print(f"После z {new_z:.6f}, p {new_p:.6f}, потеря {after:.6f}")
