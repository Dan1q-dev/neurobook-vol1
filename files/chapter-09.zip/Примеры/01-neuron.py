def neuron(x, weights, bias):
    s = sum(a * w for a, w in zip(x, weights)) + bias
    return s, max(0, s)

x = [2, 1]
for weights, bias in (([0.5, 1], -1), ([-0.5, -0.5], 0.5)):
    s, h = neuron(x, weights, bias)
    print(f"До активации {s:.1f}, после {h:.1f}")
