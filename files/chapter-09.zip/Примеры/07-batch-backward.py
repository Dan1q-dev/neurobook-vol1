import numpy as np

X = np.array([[2.0, 1.0], [0.5, 0.0]])
y = np.array([1.0, 0.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b = np.array([-1.0, 0.5])
v = np.array([1.0, -1.0])
c = -1.0

S = X @ W + b
H = np.maximum(S, 0)
z = H @ v + c
p = 1 / (1 + np.exp(-z))
loss = np.logaddexp(0, (1 - 2 * y) * z).mean()

dz = (p - y) / len(y)
dS = np.where(S > 0, dz[:, None] * v, 0.0)
dW = X.T @ dS
db = dS.sum(axis=0)
dv = H.T @ dz
dc = dz.sum()
print("Формы X, H, dz", X.shape, H.shape, dz.shape)
print("p", p.round(6).tolist(), f"потеря {loss:.6f}")
print("dW", dW.round(6).tolist())
print("db", db.round(6).tolist(), "dv", dv.round(6).tolist())
print(f"dc {dc:.6f}")
