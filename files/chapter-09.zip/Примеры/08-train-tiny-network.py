import numpy as np

X = np.array([[2.0, 1.0], [0.5, 0.0]])
y = np.array([1.0, 0.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
c, rate = -1.0, 0.1

for step in range(41):
    S = X @ W + b
    H = np.maximum(S, 0)
    z = H @ v + c
    p = 1 / (1 + np.exp(-z))
    loss = np.logaddexp(0, (1 - 2 * y) * z).mean()
    if step in (0, 10, 40):
        print(f"{step}: потеря {loss:.6f}, p {p.round(6).tolist()}")
    if step == 40:
        break

    dz = (p - y) / len(y)
    dS = np.where(S > 0, dz[:, None] * v, 0.0)
    dW, db = X.T @ dS, dS.sum(axis=0)
    dv, dc = H.T @ dz, dz.sum()
    W, b = W - rate * dW, b - rate * db
    v, c = v - rate * dv, c - rate * dc
