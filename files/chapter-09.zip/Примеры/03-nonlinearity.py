for x in (-2, -1, 0, 1, 2):
    a = max(0, x)
    b = max(0, -x)
    print("x", x, "промежуточные", a, b, "сумма", a + b)
