import numpy as np

theta = np.array([0.5, -0.5, 1.0, -0.5, -1.0, 0.5, 1.0, -1.0, -1.0])
x = np.array([2.0, 1.0])

def loss(values):
    W = values[:4].reshape(2, 2)
    b, v, c = values[4:6], values[6:8], values[8]
    h = np.maximum(x @ W + b, 0)
    z = h @ v + c
    return np.logaddexp(0, -z)

eps = 1e-5
numerical = np.zeros_like(theta)
for i in range(len(theta)):
    plus, minus = theta.copy(), theta.copy()
    plus[i] += eps
    minus[i] -= eps
    numerical[i] = (loss(plus) - loss(minus)) / (2 * eps)

manual = [-1, 0, -0.5, 0, -0.5, 0, -0.5, 0, -0.5]
print("Численные", numerical.round(6).tolist())
print("Совпали", np.allclose(numerical, manual, rtol=0, atol=1e-7))
