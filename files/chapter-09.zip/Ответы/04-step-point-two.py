import numpy as np

x = np.array([2.0, 1.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
c, rate = -1.0, 0.2
dW = np.array([[-1.0, 0.0], [-0.5, 0.0]])
db, dv, dc = np.array([-0.5, 0.0]), np.array([-0.5, 0.0]), -0.5
W, b = W - rate * dW, b - rate * db
v, c = v - rate * dv, c - rate * dc
s = x @ W + b
z = np.maximum(s, 0) @ v + c
p = 1 / (1 + np.exp(-z))
print("W", W.round(2).tolist(), "b", b.round(2).tolist())
print("v", v.round(2).tolist(), f"c {c:.2f}")
print(f"s1 {s[0]:.6f}, z {z:.6f}, p {p:.6f}")
print(f"Потеря {np.logaddexp(0, -z):.6f}")
