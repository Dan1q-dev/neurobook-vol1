import numpy as np

z = np.array([0.0, -1.25])
p = 1 / (1 + np.exp(-z))
for y in (np.array([1.0, 0.0]), np.array([1.0, 1.0])):
    loss = np.logaddexp(0, (1 - 2 * y) * z).mean()
    dz = (p - y) / len(y)
    gradient = 0.5 * (-1) * dz[1]
    print(f"Метка 301 {y[1]:.0f}, потеря {loss:.6f}")
    print(f"Градиент выбранного веса {gradient:.6f}")
