weights, downstream = [2, -3], [-0.4, 0.1]
parts = [a * b for a, b in zip(weights, downstream)]
dh = sum(parts)
print(f"Вклады {parts[0]:.1f} и {parts[1]:.1f}, сумма {dh:.1f}")
for s in (0.6, -0.6):
    ds = dh if s > 0 else 0.0
    print(f"s {s:.1f}, производная {ds:.1f}")
