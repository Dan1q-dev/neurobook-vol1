import numpy as np

x = np.array([2.0, 1.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
c = -1.0
weight, bias = W @ v, b @ v + c
direct = x @ weight + bias
two_sums = (x @ W + b) @ v + c
with_relu = np.maximum(x @ W + b, 0) @ v + c
print("Общий вес", weight.tolist(), "смещение", bias)
print("Одна сумма", direct, "две суммы", two_sums)
print("С ReLU", with_relu)
