import numpy as np

x = np.array([2.0, 1.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
s = x @ W + b
h = np.maximum(s, 0)
z = h @ v - 1
dz = 1 / (1 + np.exp(-z)) - 0
ds = np.where(s > 0, v * dz, 0.0)
print("dz", dz)
print("dW", np.outer(x, ds).tolist(), "db", ds.tolist())
print("dv", (h * dz).tolist(), "dc", dz)
