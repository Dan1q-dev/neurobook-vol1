from math import exp, log1p

def loss(shift):
    second = max(0, -1 + shift)
    z = 1 - second - 1
    return log1p(exp(-z))

eps = 0.01
slope = (loss(eps) - loss(-eps)) / (2 * eps)
print(f"Потери рядом {loss(-eps):.6f} и {loss(eps):.6f}")
print(f"Производная {slope:.6f}")
print(f"Потеря при сдвиге 1,10 {loss(1.10):.6f}")
