import numpy as np

X = np.array([[2.0, 1.0], [0.5, 0.0]])
y = np.array([1.0, 0.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
S = X @ W + b
z = np.maximum(S, 0) @ v - 1
p = 1 / (1 + np.exp(-z))
dz = (p - y) / len(y)
dS = np.where(S > 0, dz[:, None] * v, 0.0)
parts = X[:, 0] * dS[:, 1]
dW = X.T @ dS
print("Вклады", parts.round(6).tolist())
print("Матрица", dW.round(6).tolist())
