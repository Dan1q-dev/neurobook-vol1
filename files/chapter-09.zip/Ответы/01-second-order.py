import numpy as np

x = np.array([0.5, 0.0])
W = np.array([[0.5, -0.5], [1.0, -0.5]])
b, v = np.array([-1.0, 0.5]), np.array([1.0, -1.0])
s = x @ W + b
h = np.maximum(s, 0)
z = h @ v - 1
p = 1 / (1 + np.exp(-z))
loss = np.logaddexp(0, z)
print("s", s.tolist(), "h", h.tolist())
print(f"z {z:.6f}, p {p:.6f}, потеря {loss:.6f}")
