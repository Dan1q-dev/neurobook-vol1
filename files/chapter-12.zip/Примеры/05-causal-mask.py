import numpy as np
from attention_inputs import toy_qkv
from attention_math import attention

Q, K, V = toy_qkv()
allowed = np.tril(np.ones((len(Q), len(K)), dtype=bool))
_, weights, result = attention(Q, K, V, allowed)
print("Разрешения", allowed.astype(int).tolist())
print("Веса второй строки", weights[1].round(6).tolist())
print("Выход второй строки", result[1].round(6).tolist())
