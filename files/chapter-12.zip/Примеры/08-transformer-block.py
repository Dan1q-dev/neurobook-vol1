import torch
from torch import nn

torch.manual_seed(7)
X = torch.tensor([[[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 1.0],
                   [0.0, 0.0, 1.0, 2.0]]])
block = nn.TransformerEncoderLayer(d_model=4, nhead=2, dim_feedforward=8,
                                   dropout=0.0, batch_first=True, norm_first=True)
vocabulary_head = nn.Linear(4, 5)
block.eval()
mask = torch.full((3, 3), float("-inf")).triu(diagonal=1)
changed = X.clone()
changed[0, 2, 0] += 3.0
with torch.inference_mode():
    hidden = block(X, src_mask=mask)
    other = block(changed, src_mask=mask)
    logits = vocabulary_head(hidden)
print("Форма скрытых векторов", tuple(hidden.shape))
print("Форма логитов", tuple(logits.shape))
print("Первые две позиции совпали", torch.allclose(hidden[:, :2], other[:, :2]))
print("Последняя изменилась", not torch.allclose(hidden[:, 2], other[:, 2]))
