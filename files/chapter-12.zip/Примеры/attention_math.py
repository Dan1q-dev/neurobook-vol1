import numpy as np
from attention_inputs import toy_qkv

def attention(Q, K, V, allowed=None):
    scores = Q @ K.T / np.sqrt(K.shape[1])
    if allowed is not None:
        scores = np.where(allowed, scores, -np.inf)
    terms = np.exp(scores - scores.max(axis=1, keepdims=True))
    weights = terms / terms.sum(axis=1, keepdims=True)
    return scores, weights, weights @ V

if __name__ == "__main__":
    Q, K, V = toy_qkv()
    scores, weights, result = attention(Q, K, V)
    print("Оценки", scores.tolist())
    print("Суммы весов", weights.sum(axis=1).round(6).tolist())
    print("Выходы")
    for row in result.round(6).tolist():
        print(row)
