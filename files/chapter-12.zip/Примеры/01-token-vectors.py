import numpy as np

tokens = "курьер везёт заказ".split()
vocab = {"курьер": 0, "везёт": 1, "заказ": 2}
ids = [vocab[token] for token in tokens]
embeddings = np.eye(3, 4)
positions = np.zeros((len(ids), 4))
positions[:, 3] = np.arange(len(ids))
X = embeddings[ids] + positions
print("Токены", tokens)
print("Номера", ids)
print("Форма входа", X.shape)
for row in X.tolist():
    print(row)
