from math import exp, sqrt

q = [0, 2, 0, 0]
keys = [[1, 0, 0, 0], [0, 1, 1, 0], [2, 2, 0, 1]]
values = [[2, 0], [0, 2], [2, 2]]
scores = [sum(a * b for a, b in zip(q, k)) / sqrt(len(k)) for k in keys]
largest = max(scores)
terms = [exp(score - largest) for score in scores]
total = sum(terms)
weights = [term / total for term in terms]
result = []
for coordinate in range(len(values[0])):
    column = [value[coordinate] for value in values]
    result.append(sum(w * value for w, value in zip(weights, column)))
print("Оценки", scores)
print("Веса", [round(w, 6) for w in weights])
print("Выход", [round(value, 6) for value in result])
