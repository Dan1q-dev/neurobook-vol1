import numpy as np

def toy_qkv():
    X = np.array([[1, 0, 0, 0], [0, 1, 0, 1], [0, 0, 1, 2]], dtype=float)
    WQ = np.array([[2, 0, 1, 0], [0, 2, 0, 0], [2, 2, 0, 0], [0, 0, 0, 0]])
    WK = np.array([[1, 0, 0, 0], [0, 0, 1, 0], [2, 0, 0, 1], [0, 1, 0, 0]])
    WV = np.array([[2, 0], [0, 2], [2, 2], [0, 0]])
    return X @ WQ, X @ WK, X @ WV

if __name__ == "__main__":
    Q, K, V = toy_qkv()
    for name, matrix in (("Q", Q), ("K", K), ("V", V)):
        print(name, matrix.shape)
        for row in matrix.tolist():
            print(row)
