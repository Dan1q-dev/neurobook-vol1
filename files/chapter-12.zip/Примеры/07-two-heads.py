from math import sqrt
import torch

projected = torch.tensor([[1.0, 0.0, 0.0, 1.0],
                          [0.0, 2.0, 1.0, 1.0]], dtype=torch.float64)
heads = projected.reshape(2, 2, 2).transpose(0, 1)
scores = heads @ heads.transpose(-2, -1) / sqrt(2)
weights = scores.softmax(dim=-1)
contexts = weights @ heads
joined = contexts.transpose(0, 1).reshape(2, 4)
print("Форма по головам", tuple(contexts.shape))
print("Веса для первой позиции")
for row in weights[:, 0].numpy().round(6).tolist():
    print(row)
print("Первая строка после объединения", joined[0].numpy().round(6).tolist())
