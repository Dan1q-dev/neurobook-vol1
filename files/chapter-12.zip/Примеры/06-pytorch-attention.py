import numpy as np
import torch
from torch.nn import functional as F
from attention_inputs import toy_qkv
from attention_math import attention

Q, K, V = toy_qkv()
q = torch.from_numpy(Q)[None, None]
k = torch.from_numpy(K)[None, None]
v = torch.from_numpy(V)[None, None]
for causal in (False, True):
    allowed = np.tri(len(Q), dtype=bool) if causal else None
    _, _, reference = attention(Q, K, V, allowed)
    result = F.scaled_dot_product_attention(q, k, v, is_causal=causal,
                                            dropout_p=0.0)
    same = torch.allclose(result[0, 0], torch.from_numpy(reference))
    print(f"Причинное {causal}, форма {tuple(result.shape)}, совпало {same}")
    print("Вторая строка", result[0, 0, 1].numpy().round(6).tolist())
