import numpy as np

vocab = {"курьер": 0, "везёт": 1, "заказ": 2}
ids = [vocab[token] for token in "заказ везёт заказ".split()]
positions = np.zeros((3, 4))
positions[:, 3] = np.arange(3)
X = np.eye(3, 4)[ids] + positions
print("Номера", ids)
for row in X.tolist():
    print(row)
print("Различные координаты", (np.flatnonzero(X[0] != X[2]) + 1).tolist())
