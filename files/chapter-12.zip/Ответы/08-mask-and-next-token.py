import numpy as np

tokens = [0, 1, 2, 3]
print("Вход", tokens[:-1], "цели", tokens[1:])
scores = np.zeros(3)
masked = np.where([True, False, False], scores, -np.inf)
full_terms, causal_terms = np.exp(scores), np.exp(masked)
full = full_terms / full_terms.sum()
causal = causal_terms / causal_terms.sum()
for future in (9.0, 12.0):
    V = np.array([1.0, 2.0, future])
    print(f"Будущее {future:.0f}, полный выход {full @ V:.1f}, с маской {causal @ V:.1f}")
