import torch
from torch import nn

x = torch.tensor([1.0, 3.0, 1.0, 3.0])
norm = nn.LayerNorm(4, eps=0.0, elementwise_affine=False)
normalized = norm(x)
branch = 2 * normalized
print("Нормировка", normalized.tolist())
print("Ветвь", branch.tolist())
print("Сумма", (x + branch).tolist())
