from math import sqrt
import torch

q = torch.tensor([0.0, 1.0], dtype=torch.float64)
V = torch.tensor([[0.0, 1.0], [1.0, 1.0]], dtype=torch.float64)
new_keys = V.clone()
new_keys[1, 1] = 0.0
for label, K in (("До", V), ("После", new_keys)):
    weights = (K @ q / sqrt(2)).softmax(dim=0)
    print(label, weights.numpy().round(6).tolist(),
          (weights @ V).numpy().round(6).tolist())
