import numpy as np

causal = np.tri(3, dtype=bool)
real_keys = np.array([True, True, False])
allowed = causal & real_keys
scores = np.array([1.0, 1.0, 4.0])
masked = np.where(allowed[2], scores, -np.inf)
terms = np.exp(masked - masked.max())
for row in allowed.astype(int).tolist():
    print(row)
print("Веса третьей строки", (terms / terms.sum()).tolist())
