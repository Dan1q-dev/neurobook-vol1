import numpy as np

q = np.array([2.0, 0.0, 1.0, 0.0])
K = np.array([[1, 0, 0, 0], [0, 1, 1, 0], [2, 2, 0, 1]])
V = np.array([[2, 0], [0, 2], [2, 2]])
scores = q @ K.T / np.sqrt(K.shape[1])
terms = np.exp(scores - scores.max())
weights = terms / terms.sum()
print("Оценки", scores.tolist())
print("Веса", weights.round(6).tolist())
print("Выход", (weights @ V).round(6).tolist())
