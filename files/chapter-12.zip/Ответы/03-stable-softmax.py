from math import exp

def stable_softmax(scores):
    largest = max(scores)
    terms = [exp(value - largest) for value in scores]
    return [term / sum(terms) for term in terms]

for scores in ([1000, 1001, 1002], [0, 1, 2]):
    weights = stable_softmax(scores)
    print([round(value, 6) for value in weights])
