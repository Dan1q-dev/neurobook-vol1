import numpy as np

Q = np.array([[1.0, 0.0], [0.0, 1.0]])
K = np.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
V = K.copy()
scores = Q @ K.T / np.sqrt(K.shape[1])
terms = np.exp(scores - scores.max(axis=1, keepdims=True))
weights = terms / terms.sum(axis=1, keepdims=True)
Y = weights @ V
print("Форма оценок", scores.shape)
print("Форма выхода", Y.shape)
for row in Y.round(6).tolist():
    print(row)
