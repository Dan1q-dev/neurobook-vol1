import torch

w = torch.tensor(2.0, requires_grad=True)
for steps in (1, 2):
    w.grad = None
    for _ in range(steps):
        ((3 * w - 7) ** 2).backward()
    with torch.no_grad():
        new_w = w - 0.1 * w.grad
        new_loss = (3 * new_w - 7) ** 2
    print(f"Вызовов {steps}, градиент {w.grad.item():.1f}")
    print(f"Новый вес {new_w.item():.1f}, потеря {new_loss.item():.2f}")
