sizes = [2, 2, 1]
means = [0.2, 0.4, 0.8]
total = sum(size * mean for size, mean in zip(sizes, means))
print(f"По строкам {total / sum(sizes):.6f}")
print(f"По пакетам {sum(means) / len(means):.6f}")
