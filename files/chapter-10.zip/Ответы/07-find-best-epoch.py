from csv import DictReader

with open("learning-curve.csv", encoding="utf-8", newline="") as file:
    rows = list(DictReader(file))
best = min(rows, key=lambda row: float(row["val_loss"]))
for row in (best, rows[-1]):
    train = float(row["train_loss"])
    val = float(row["val_loss"])
    print(f"Эпоха {row['epoch']}, train {train:.6f}, val {val:.6f}")
