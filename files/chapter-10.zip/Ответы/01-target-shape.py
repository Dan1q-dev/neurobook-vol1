import torch
from torch import nn

z = torch.tensor([[0.0], [-1.25]])
labels = torch.tensor([1, 0])
y = labels.float().unsqueeze(1)
print("До", tuple(labels.shape), labels.dtype)
print("После", tuple(y.shape), y.dtype)
criterion = nn.BCEWithLogitsLoss()
loss = criterion(z, y)
print(f"Средняя потеря {loss.item():.6f}")
