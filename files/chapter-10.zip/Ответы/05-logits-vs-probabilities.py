import torch
from torch import nn

z, y = torch.tensor([[0.0]]), torch.tensor([[1.0]])
criterion = nn.BCEWithLogitsLoss()
print(f"Подали логит {criterion(z, y).item():.6f}")
print(f"Подали вероятность {criterion(torch.sigmoid(z), y).item():.6f}")
