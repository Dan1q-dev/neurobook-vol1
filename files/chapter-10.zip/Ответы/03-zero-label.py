import torch
from torch import nn

model = nn.Sequential(nn.Linear(2, 2), nn.ReLU(), nn.Linear(2, 1))
with torch.no_grad():
    model[0].weight.copy_(torch.tensor([[0.5, 1.0], [-0.5, -0.5]]))
    model[0].bias.copy_(torch.tensor([-1.0, 0.5]))
    model[2].weight.copy_(torch.tensor([[1.0, -1.0]]))
    model[2].bias.fill_(-1.0)
z = model(torch.tensor([[2.0, 1.0]]))
criterion = nn.BCEWithLogitsLoss()
loss = criterion(z, torch.tensor([[0.0]]))
loss.backward()
print("Первый слой", model[0].weight.grad.tolist(),
      model[0].bias.grad.tolist())
print("Выходной слой", model[2].weight.grad.tolist(),
      model[2].bias.grad.tolist())
print("Вес [0, 1]", model[0].weight.grad[0, 1].item())
