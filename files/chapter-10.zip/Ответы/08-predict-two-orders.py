import torch
from torch import nn

saved = torch.load("delivery-ch10.pt", map_location="cpu", weights_only=True)
width = saved["hidden_size"]
model = nn.Sequential(nn.Linear(len(saved["columns"]), width),
                      nn.ReLU(), nn.Linear(width, 1))
model.load_state_dict(saved["state_dict"])
model.eval()
orders = [{"distance_km": 4.0, "rush": 1.0},
          {"distance_km": 2.0, "rush": 1.0}]
for order in orders:
    order["distance_km"] /= saved["scale"]
X = torch.tensor([[order[name] for name in saved["columns"]] for order in orders])
with torch.inference_mode():
    all_at_once = torch.sigmoid(model(X)).flatten()
    one_by_one = torch.cat([torch.sigmoid(model(row[None])) for row in X]).flatten()
print("Вероятности", [round(p, 6) for p in all_at_once.tolist()])
print("Совпадают", torch.allclose(all_at_once, one_by_one))
print("Классы", (all_at_once >= saved["threshold"]).int().tolist())
