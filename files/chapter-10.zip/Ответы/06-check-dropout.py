import torch
from torch import nn

torch.manual_seed(7)
layer = nn.Dropout(0.25)
x = torch.ones(8, requires_grad=True)
active = layer(x)
nonzero = active[active != 0]
print("Значения train", sorted({round(v, 6) for v in nonzero.tolist()}))
layer.eval()
total = layer(x).sum()
with torch.inference_mode():
    checked = layer(x).sum()
print("eval", total.item(), total.requires_grad)
print("eval и inference_mode", checked.item(), checked.requires_grad)
