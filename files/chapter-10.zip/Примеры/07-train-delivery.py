from copy import deepcopy
from csv import DictReader
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

def tensors(rows):
    X = [[float(r["distance_km"]) / 2, int(r["rush"])] for r in rows]
    y = [[float(r["late"])] for r in rows]
    return torch.tensor(X), torch.tensor(y)

with open("orders-late.csv", encoding="utf-8", newline="") as file:
    rows = list(DictReader(file))
train = tensors([r for r in rows if int(r["day"]) <= 20])
val = tensors([r for r in rows if 21 <= int(r["day"]) <= 28])
test = tensors([r for r in rows if int(r["day"]) >= 29])
torch.set_num_threads(1)
torch.manual_seed(7)
loader = DataLoader(TensorDataset(*train), batch_size=5, shuffle=True,
                    generator=torch.Generator().manual_seed(19))
model = nn.Sequential(nn.Linear(2, 16), nn.ReLU(), nn.Linear(16, 1))
criterion = nn.BCEWithLogitsLoss()
opt = torch.optim.Adam(model.parameters(), lr=0.03)
best_loss, curve = float("inf"), []
for epoch in range(1, 121):
    model.train()
    for xb, yb in loader:
        opt.zero_grad()
        criterion(model(xb), yb).backward()
        opt.step()
    model.eval()
    with torch.inference_mode():
        train_loss = criterion(model(train[0]), train[1]).item()
        val_loss = criterion(model(val[0]), val[1]).item()
    curve.append((epoch, train_loss, val_loss))
    if val_loss < best_loss:
        best_epoch, best_loss = epoch, val_loss
        best_state = deepcopy(model.state_dict())
    if epoch in (1, 10, 40, 80, 120):
        print(f"{epoch}: train {train_loss:.6f}, val {val_loss:.6f}")
model.load_state_dict(best_state)
with torch.inference_mode():
    z = model(test[0])
    test_loss = criterion(z, test[1]).item()
    correct = (torch.sigmoid(z) >= 0.5) == test[1]
print(f"Лучшая эпоха {best_epoch}, val {best_loss:.6f}")
print(f"Потеря test {test_loss:.6f}, верно {correct.sum().item()}/{correct.numel()}")
torch.save({"state_dict": best_state, "epoch": best_epoch,
            "hidden_size": 16, "columns": ["distance_km", "rush"],
            "scale": 2.0, "threshold": 0.5}, "delivery-ch10.pt")
