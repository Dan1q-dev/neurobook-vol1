import csv
import torch
from torch import nn

torch.set_num_threads(1)
torch.manual_seed(17)
random = torch.Generator().manual_seed(7)

def make_data(n):
    X = torch.rand(n, 8, generator=random)
    y = (X[:, :1] > 0.5).float()
    flip = torch.rand(n, 1, generator=random) < 0.16
    return X, torch.where(flip, 1 - y, y)

X_train, y_train = make_data(96)
X_val, y_val = make_data(256)
model = nn.Sequential(nn.Linear(8, 64), nn.ReLU(),
                      nn.Linear(64, 64), nn.ReLU(), nn.Linear(64, 1))
opt = torch.optim.Adam(model.parameters(), lr=0.01)
criterion = nn.BCEWithLogitsLoss()
history = []
for epoch in range(1, 201):
    opt.zero_grad()
    loss = criterion(model(X_train), y_train)
    loss.backward()
    opt.step()
    with torch.inference_mode():
        train = criterion(model(X_train), y_train).item()
        val = criterion(model(X_val), y_val).item()
    history.append((epoch, train, val))

def val_loss(row):
    return row[2]

best = min(history, key=val_loss)
for epoch, train, val in (history[0], best, history[-1]):
    print(f"Эпоха {epoch}, train {train:.4f}, val {val:.4f}")
with open("overfit-curve.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["epoch", "train", "val"])
    writer.writerows(history)
