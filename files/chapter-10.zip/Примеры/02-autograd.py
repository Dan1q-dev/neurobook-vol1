import torch

w = torch.tensor(2.0, requires_grad=True)

def loss():
    return (3 * w - 7) ** 2

current = loss()
current.backward()
print(f"Потеря {current.item():.1f}, градиент {w.grad.item():.1f}")
loss().backward()
print(f"После второго вызова {w.grad.item():.1f}")
w.grad.zero_()
loss().backward()
print(f"После очистки и расчёта {w.grad.item():.1f}")
