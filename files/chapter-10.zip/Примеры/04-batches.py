import torch
from torch.utils.data import DataLoader, TensorDataset

X = torch.tensor([[0.5, 0.0], [1.0, 0.0], [1.0, 1.0],
                  [2.0, 0.0], [2.0, 1.0]])
y = torch.tensor([[0.0], [0.0], [0.0], [0.0], [1.0]])
loader = DataLoader(TensorDataset(X, y), batch_size=2, shuffle=False)
for number, (xb, yb) in enumerate(loader, start=1):
    print(number, tuple(xb.shape), tuple(yb.shape), yb.flatten().tolist())
