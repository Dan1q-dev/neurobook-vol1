import torch
from torch import nn

model = nn.Sequential(nn.Linear(2, 2), nn.ReLU(), nn.Linear(2, 1))
with torch.no_grad():
    model[0].weight.copy_(torch.tensor([[0.5, 1.0], [-0.5, -0.5]]))
    model[0].bias.copy_(torch.tensor([-1.0, 0.5]))
    model[2].weight.copy_(torch.tensor([[1.0, -1.0]]))
    model[2].bias.fill_(-1.0)
opt = torch.optim.SGD(model.parameters(), lr=0.1)
X, y = torch.tensor([[2.0, 1.0]]), torch.tensor([[1.0]])
criterion = nn.BCEWithLogitsLoss()

opt.zero_grad()
before = criterion(model(X), y)
before.backward()
opt.step()

with torch.inference_mode():
    z = model(X)
    p = torch.sigmoid(z)
    after = criterion(z, y)
print(f"Вес {model[0].weight[0, 0].item():.3f}")
print(f"z {z.item():.6f}, p {p.item():.6f}")
print(f"Потеря {before.item():.6f}, после {after.item():.6f}")
