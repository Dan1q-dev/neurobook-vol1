import torch
from torch import nn

torch.manual_seed(7)
dropout = nn.Dropout(0.5)
x = torch.ones(8, requires_grad=True)
dropout.train()
during_training = dropout(x)
print("Значения train", sorted(set(during_training.tolist())))

dropout.eval()
checked = dropout(x).sum()
with torch.inference_mode():
    reported = dropout(x).sum()
print("Сумма eval", checked.item())
print("Градиенты eval", checked.requires_grad)
print("Градиенты в inference_mode", reported.requires_grad)
