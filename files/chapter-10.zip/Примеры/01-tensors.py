import torch

X = torch.tensor([[2.0, 1.0], [0.5, 0.0]], dtype=torch.float32)
y = torch.tensor([[1.0], [0.0]], dtype=torch.float32)
w = torch.tensor([0.5, 1.0])
s = X @ w - 1
h = torch.relu(s)

print("Формы X и y", tuple(X.shape), tuple(y.shape))
print("Тип X", X.dtype)
print("Первая строка", X[0].tolist())
print("Суммы", s.tolist())
print("ReLU", h.tolist())
