import torch
from torch import nn

model = nn.Sequential(nn.Linear(2, 2), nn.ReLU(), nn.Linear(2, 1))
with torch.no_grad():
    model[0].weight.copy_(torch.tensor([[0.5, 1.0], [-0.5, -0.5]]))
    model[0].bias.copy_(torch.tensor([-1.0, 0.5]))
    model[2].weight.copy_(torch.tensor([[1.0, -1.0]]))
    model[2].bias.fill_(-1.0)

X, y = torch.tensor([[2.0, 1.0]]), torch.tensor([[1.0]])
z = model(X)
criterion = nn.BCEWithLogitsLoss()
loss = criterion(z, y)
loss.backward()

print("Форма z", tuple(z.shape))
print(f"z {z.item():.6f}, потеря {loss.item():.6f}")
print("Первый слой", model[0].weight.grad.tolist(),
      model[0].bias.grad.tolist())
print("Выходной слой", (model[2].weight.grad + 0.0).tolist(),
      model[2].bias.grad.tolist())
