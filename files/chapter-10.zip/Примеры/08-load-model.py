import torch
from torch import nn

saved = torch.load("delivery-ch10.pt", map_location="cpu", weights_only=True)
width = saved["hidden_size"]
model = nn.Sequential(nn.Linear(len(saved["columns"]), width),
                      nn.ReLU(), nn.Linear(width, 1))
model.load_state_dict(saved["state_dict"])
model.eval()

order = {"distance_km": 4.0, "rush": 1.0}
order["distance_km"] /= saved["scale"]
X = torch.tensor([[order[name] for name in saved["columns"]]])
with torch.inference_mode():
    z = model(X)
    p = torch.sigmoid(z).item()
late = int(p >= saved["threshold"])
print(f"Эпоха {saved['epoch']}, вход {X.tolist()}")
print(f"Логит {z.item():.6f}, вероятность {p:.6f}, класс {late}")
