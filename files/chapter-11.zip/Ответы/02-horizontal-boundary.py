import torch
from torch.nn import functional as F

X = torch.tensor([[0.0] * 4, [0.0] * 4, [1.0] * 4, [1.0] * 4])
X = X.reshape(1, 1, 4, 4)
vertical = torch.tensor([[-1.0, 1.0], [-1.0, 1.0]])
horizontal = torch.tensor([[-1.0, -1.0], [1.0, 1.0]])
first = F.conv2d(X, vertical.reshape(1, 1, 2, 2))
second = F.conv2d(X, horizontal.reshape(1, 1, 2, 2))
print("Первый фильтр, левый край", first[0, 0, :, 0].tolist())
print("Второй фильтр")
for row in second[0, 0].tolist():
    print(row)
