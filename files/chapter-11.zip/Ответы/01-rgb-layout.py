import torch

images = torch.zeros(2, 2, 2, 3, dtype=torch.int64)
images[0, 0, 0, 0] = 255
images[1, 0, 0, 1] = 255
X = images.permute(0, 3, 1, 2).float() / 255
print("Входная форма", tuple(images.shape))
print("Форма PyTorch", tuple(X.shape))
print("Первые пиксели", X[:, :, 0, 0].tolist())
