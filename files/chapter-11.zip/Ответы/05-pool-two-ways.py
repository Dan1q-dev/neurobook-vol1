import torch
from torch import nn

X = torch.tensor([[-1.0, 2.0, 0.0, 1.0], [0.0, 1.0, 3.0, 0.0],
                  [2.0, 0.0, -2.0, 1.0], [1.0, -4.0, 0.0, 0.0]])
active = X.reshape(1, 1, 4, 4).relu()
local_pool = nn.MaxPool2d(2, stride=2)
local = local_pool(active)
global_pool = nn.AdaptiveMaxPool2d(1)
whole = global_pool(active)
print("После ReLU")
for row in active[0, 0].tolist():
    print(row)
print("Локально", local[0, 0].tolist())
print("Глобально", whole.item())
