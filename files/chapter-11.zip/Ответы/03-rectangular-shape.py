import torch
from torch.nn import functional as F

X = torch.zeros(1, 1, 6, 7)
weights = torch.ones(1, 1, 3, 3)
for padding in (1, 0):
    manual = tuple((side + 2 * padding - 3) // 2 + 1 for side in (6, 7))
    computed = F.conv2d(X, weights, stride=2, padding=padding)
    print(f"Дополнение {padding}, вручную {manual}, PyTorch {tuple(computed.shape[-2:])}")
