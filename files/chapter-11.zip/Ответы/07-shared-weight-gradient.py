import torch
from torch import nn

X = torch.tensor([[[[1.0, 2.0], [0.0, -1.0]]]])
target = torch.zeros_like(X)
layer = nn.Conv2d(1, 1, 1, bias=False)
with torch.no_grad():
    layer.weight.fill_(1.0)
opt = torch.optim.SGD(layer.parameters(), lr=0.1)
criterion = nn.MSELoss()
opt.zero_grad()
loss = criterion(layer(X), target)
loss.backward()
print(f"Потеря {loss.item():.3f}, градиент {layer.weight.grad.item():.3f}")
opt.step()
with torch.inference_mode():
    after = criterion(layer(X), target)
print(f"Вес {layer.weight.item():.3f}, потеря после {after.item():.3f}")
