from pathlib import Path
import sys

chapter = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(chapter / "Примеры"))
from patterns import make_patterns

def locations(images, labels):
    rows = images[labels == 0, 0].sum(dim=2).argmax(dim=1)
    cols = images[labels == 1, 0].sum(dim=1).argmax(dim=1)
    return set(rows.tolist() + cols.tolist())

train = make_patterns(48, seed=31)
test = make_patterns(16, seed=101, positions=(1, 6))
train_places = locations(*train)
test_places = locations(*test)
y = test[1]
print("Обучение", sorted(train_places))
print("Тест", sorted(test_places))
print("Общие позиции", sorted(train_places & test_places))
print(f"Постоянный класс 0: {(y == 0).sum().item()}/{len(y)}")
