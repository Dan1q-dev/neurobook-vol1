import torch
from torch import nn

X = torch.zeros(5, 3, 8, 8)
for use_bias in (True, False):
    layer = nn.Conv2d(3, 6, 3, padding=1, bias=use_bias)
    count = sum(parameter.numel() for parameter in layer.parameters())
    print(f"Смещение {use_bias}, форма {tuple(layer(X).shape)}, параметров {count}")
