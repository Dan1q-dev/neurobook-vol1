import torch
from torch import nn

z = torch.tensor([[1.0, -1.0], [6.0, 4.0]])
y = torch.tensor([1, 1])
probabilities = z.softmax(dim=1)[:, 1]
criterion = nn.CrossEntropyLoss(reduction="none")
losses = criterion(z, y)
print("Класс 1", [round(p, 6) for p in probabilities.tolist()])
print("Прогнозы", z.argmax(dim=1).tolist())
print("Потери", [round(loss, 6) for loss in losses.tolist()])
