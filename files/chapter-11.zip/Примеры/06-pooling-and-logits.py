import torch
from torch import nn

features = torch.tensor([[[-1.0, 2.0, 0.0, 1.0], [0.0, 1.0, 3.0, 0.0],
                          [2.0, 0.0, -2.0, 1.0], [1.0, 4.0, 0.0, 0.0]]])
pool = nn.MaxPool2d(2, stride=2)
pooled = pool(features.unsqueeze(0).relu())
linear = nn.Linear(4, 2, bias=False)
with torch.no_grad():
    linear.weight.copy_(torch.tensor([[1.0, 0.0, 0.0, -1.0],
                                      [-1.0, 0.0, 0.0, 1.0]]))
    logits = linear(pooled.flatten(start_dim=1))
y = torch.tensor([0])
criterion = nn.CrossEntropyLoss()
loss = criterion(logits, y)
print("Пулинг", pooled[0, 0].tolist())
print("Логиты", logits.tolist())
print("Вероятности", [round(p, 6) for p in logits.softmax(1)[0].tolist()])
print(f"Класс {logits.argmax(1).item()}, потеря {loss.item():.6f}")
