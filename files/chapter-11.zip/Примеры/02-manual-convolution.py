image = [[0, 0, 1, 1] for _ in range(4)]
kernel = [[-1, 1], [-1, 1]]
height, width = len(image), len(image[0])
kh, kw = len(kernel), len(kernel[0])
features = []

for top in range(height - kh + 1):
    row = []
    for left in range(width - kw + 1):
        total = 0
        for dy in range(kh):
            for dx in range(kw):
                total += image[top + dy][left + dx] * kernel[dy][dx]
        row.append(total)
    features.append(row)

for row in features:
    print(row)
