import torch

def make_patterns(pairs, seed, positions=(2, 3, 4, 5)):
    rng = torch.Generator().manual_seed(seed)
    y = torch.tensor([0, 1]).repeat(pairs)
    X = 0.15 * torch.rand(len(y), 1, 8, 8, generator=rng)
    allowed = torch.tensor(positions)
    place = allowed[torch.randint(len(allowed), (len(y),), generator=rng)]
    strength = 0.60 + 0.25 * torch.rand(len(y), generator=rng)
    for index, label in enumerate(y.tolist()):
        position = place[index].item()
        brightness = strength[index]
        if label == 0:
            X[index, 0, position, :] += brightness
        else:
            X[index, 0, :, position] += brightness
    return X, y

if __name__ == "__main__":
    images, labels = make_patterns(4, seed=31)
    print("Картинки", tuple(images.shape))
    print("Классы", labels.tolist())
    print("Яркости в диапазоне", ((images >= 0) & (images <= 1)).all().item())
