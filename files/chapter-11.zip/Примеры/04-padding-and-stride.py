import torch
from torch.nn import functional as F

X = torch.arange(1, 26, dtype=torch.float32).reshape(1, 1, 5, 5)
weights = torch.ones(1, 1, 3, 3)
plain = F.conv2d(X, weights, stride=2)
padded = F.conv2d(X, weights, stride=2, padding=1)
print("Без дополнения", tuple(plain.shape[-2:]))
print("С дополнением", tuple(padded.shape[-2:]))
for row in padded[0, 0].tolist():
    print(row)
