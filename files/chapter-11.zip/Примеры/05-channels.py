import torch
from torch.nn import functional as F

X = torch.tensor([[[[0.0, 1.0], [0.0, 1.0]],
                   [[0.0, 0.0], [1.0, 1.0]]]])
weights = torch.tensor([[[[-1.0, 1.0], [-1.0, 1.0]],
                         [[1.0, 1.0], [1.0, 1.0]]],
                        [[[0.0, 0.0], [0.0, 0.0]],
                         [[-1.0, -1.0], [1.0, 1.0]]]])
bias = torch.tensor([0.5, -0.5])
Y = F.conv2d(X, weights, bias)
print("Форма весов", tuple(weights.shape))
print("Форма карт", tuple(Y.shape))
print("Отклики", Y.flatten().tolist())
print("Параметров", weights.numel() + bias.numel())
