import torch
from torch import nn

image = torch.tensor([[0.0, 0.0, 1.0, 1.0]] * 4)
X = image.reshape(1, 1, 4, 4)
kernel = torch.tensor([[-1.0, 1.0], [-1.0, 1.0]])
layer = nn.Conv2d(1, 1, 2, bias=False)
with torch.no_grad():
    layer.weight.copy_(kernel.reshape(1, 1, 2, 2))
    features = layer(X)
    inverted = layer(1 - X)
print("Форма выхода", tuple(features.shape))
print("Карта", features[0, 0].tolist())
print("Первая строка после инверсии", inverted[0, 0, 0].tolist())
