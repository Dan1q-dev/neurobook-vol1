import torch

raw = torch.tensor([[0, 64, 128], [192, 255, 0]])
image = raw.float() / 255
X = image.unsqueeze(0).unsqueeze(0)
print("Форма таблицы", tuple(raw.shape))
print("Форма входа", tuple(X.shape))
print(f"128 / 255 = {X[0, 0, 0, 2].item():.6f}")
print(f"255 / 255 = {X[0, 0, 1, 1].item():.6f}")
