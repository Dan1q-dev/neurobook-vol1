import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from patterns import make_patterns

torch.set_num_threads(1)
torch.manual_seed(7)
X_train, y_train = make_patterns(48, seed=31)
X_val, y_val = make_patterns(16, seed=67)
X_test, y_test = make_patterns(16, seed=101, positions=(1, 6))
dataset = TensorDataset(X_train, y_train)
generator = torch.Generator().manual_seed(23)
loader = DataLoader(dataset, batch_size=16, shuffle=True, generator=generator)
model = nn.Sequential(nn.Flatten(), nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 2))
opt = torch.optim.Adam(model.parameters(), lr=0.02)
criterion = nn.CrossEntropyLoss()

for _ in range(12):
    for xb, yb in loader:
        opt.zero_grad()
        loss = criterion(model(xb), yb)
        loss.backward()
        opt.step()

model.eval()
with torch.inference_mode():
    for name, X, y in (("Обучение", X_train, y_train),
                       ("Валидация", X_val, y_val), ("Тест", X_test, y_test)):
        correct = (model(X).argmax(1) == y).sum().item()
        print(f"{name}: {correct}/{len(y)}")
