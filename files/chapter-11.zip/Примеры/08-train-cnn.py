import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from patterns import make_patterns

def report(label, model, data):
    X, y = data
    model.eval()
    with torch.inference_mode():
        logits = model(X)
        loss = nn.functional.cross_entropy(logits, y).item()
        correct = (logits.argmax(1) == y).sum().item()
    print(f"{label}: потеря {loss:.4f}, верно {correct}/{len(y)}")

torch.set_num_threads(1)
torch.manual_seed(7)
train = make_patterns(48, seed=31)
val = make_patterns(16, seed=67)
test = make_patterns(16, seed=101, positions=(1, 6))
loader = DataLoader(TensorDataset(*train), batch_size=16, shuffle=True,
                    generator=torch.Generator().manual_seed(23))
model = nn.Sequential(nn.Conv2d(1, 4, 3, padding=1), nn.ReLU(),
                      nn.AdaptiveMaxPool2d(1), nn.Flatten(), nn.Linear(4, 2))
opt = torch.optim.Adam(model.parameters(), lr=0.02)
criterion = nn.CrossEntropyLoss()
report("Валидация до", model, val)
for _ in range(12):
    model.train()
    for xb, yb in loader:
        opt.zero_grad()
        criterion(model(xb), yb).backward()
        opt.step()
report("Валидация после", model, val)
report("Тест", model, test)
