import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
W = np.array([[3, 5], [2, 1]])
b = np.array([5, 8])
weighted = X @ W
Y = weighted + b

print("Суммы до смещения", weighted.tolist())
print("Форма Y", Y.shape)
print("Цена и время", Y.tolist())
print("Только время", Y[:, 1].tolist())
