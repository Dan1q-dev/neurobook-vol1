import numpy as np

A = np.array([[1, 2], [3, 4]])
B = np.array([[2, 0], [1, 2]])

print("A + B", (A + B).tolist())
print("2 * A", (2 * A).tolist())
print("A * B", (A * B).tolist())
print("A @ B", (A @ B).tolist())
print("B @ A", (B @ A).tolist())
