import numpy as np

u = np.array([3, 1])
v = np.array([1, 2])
print("Форма u", u.shape)
print("Первая компонента", u[0])
print("Сумма", (u + v).tolist())
print("Разность", (u - v).tolist())
print("Удвоенный u", (2 * u).tolist())
