import numpy as np

u = np.array([3, 4])
v = np.array([4, -3])
print("Попарные произведения", (u * v).tolist())
print("Сумма произведений", (u * v).sum())
print("Скалярное произведение", u @ v)
print("Длина u", np.linalg.norm(u))
