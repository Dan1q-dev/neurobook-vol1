import numpy as np

def linear_layer(X, W, b):
    if X.ndim != 2 or W.ndim != 2:
        raise ValueError("X и W должны быть матрицами")
    if X.shape[1] != W.shape[0]:
        raise ValueError("На каждый признак нужна строка весов")
    if b.shape != (W.shape[1],):
        raise ValueError("На каждый выход нужно одно смещение")
    return X @ W + b

orders = [108, 109, 111]
X = np.array([
    [0.4, 3.0, 1, 0],
    [1.4, 2.5, 0, 1],
    [1.0, 0.5, 1, 0],
])
W = np.array([[10, 20], [1, 0], [0, 0], [3, -5]])
b = np.array([4, 12])
Y = linear_layer(X, W, b)

print("Формы X, W, b", X.shape, W.shape, b.shape)
print("Форма Y", Y.shape)
for order, result in zip(orders, Y):
    price, minutes = result
    print(f"Заказ {order}: цена {price:.1f}, время {minutes:.1f}")
