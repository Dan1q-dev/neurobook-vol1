import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
w = np.array([3, 2])
bias = 5
weighted = X @ w
predictions = weighted + bias

print("Формы X и w", X.shape, w.shape)
print("Взвешенные суммы", weighted.tolist())
print("Цены", predictions.tolist())
print("Форма результата", predictions.shape)
