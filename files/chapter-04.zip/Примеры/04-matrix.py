import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
x = X[0]
row = x.reshape(1, 2)

print("Форма X", X.shape)
print("Вторая строка, первый столбец", X[1, 0])
print("Массы", X[:, 1].tolist())
print("X.T", X.T.shape, X.T.tolist())
print("Вектор x", x.shape, "после .T", x.T.shape)
print("Строка", row.shape, "столбец", row.T.shape)
