features = [3, 2]
weights = [3, 2]
bias = 5

if len(features) != len(weights):
    raise ValueError("У каждого признака должен быть вес")

products = []
for value, weight in zip(features, weights):
    products.append(value * weight)
prediction = sum(products) + bias

print("Вклады признаков", products)
print("Прогноз цены", prediction)
