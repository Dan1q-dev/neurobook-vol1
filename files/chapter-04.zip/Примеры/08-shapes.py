import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
for w in (np.array([3, 2]), np.array([3, 2, 1])):
    expected = X.shape[1]
    actual = len(w)
    if actual == expected:
        print("Взвешенные суммы", (X @ w).tolist())
    else:
        print(f"Нужны {expected} веса, получено {actual}")
