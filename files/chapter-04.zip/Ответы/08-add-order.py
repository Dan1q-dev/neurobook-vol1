import numpy as np

X = np.array([
    [0.4, 3.0, 1, 0],
    [1.4, 2.5, 0, 1],
    [0.6, 5.0, 0, 1],
    [1.0, 0.5, 1, 0],
])
W = np.array([[10, 20], [1, 0], [0, 0], [3, -5]])
b = np.array([4, 12])
Y = X @ W + b

print("Формы X и Y", X.shape, Y.shape)
print("Заказ 110", Y[2].round(1).tolist())
