import numpy as np

u = np.array([2, -1])
v = np.array([-1, 3])

print("u + v", (u + v).tolist())
print("u - v", (u - v).tolist())
print("(-2) * v", (-2 * v).tolist())
