import numpy as np

u = np.array([1, 2])
v = np.array([3, 4])
difference = v - u

print("Произведение", u @ v)
print("Разность", difference.tolist())
print("Расстояние", round(np.linalg.norm(difference), 3))
