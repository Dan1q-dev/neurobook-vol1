import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
w = np.array([4, 1])
y = X @ w + 2
print("Цены", y.tolist())
print("Форма", y.shape)
