import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
W = np.array([[3, 5], [2, 1]])
b = np.array([5, 8])
try:
    X @ W + np.array([5, 8, 10])
except ValueError:
    print("Для двух выходов нужны два смещения")

print("С W", (X @ W + b)[0].tolist())
print("С W.T", (X @ W.T + b)[0].tolist())
