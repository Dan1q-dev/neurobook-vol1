import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
print("Формы", X.shape, X.T.shape)
print("X[1, 1]", X[1, 1])
print("Вторая строка X", X[1].tolist())
print("Второй столбец X.T", X.T[:, 1].tolist())
