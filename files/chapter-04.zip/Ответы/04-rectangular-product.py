import numpy as np

A = np.array([[2, 1, 0], [1, 3, 2]])
B = np.array([[1, 2], [0, 1], [2, 0]])
AB = A @ B
BA = B @ A
print("A @ B", AB.shape, AB.tolist())
print("B @ A", BA.shape, BA.tolist())
