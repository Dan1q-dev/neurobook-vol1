import numpy as np

X = np.array([[3, 2], [1, 4], [2, 1]])
W = np.array([[3, 5], [2, 1]])
old = X @ W + np.array([5, 8])
new = X @ W + np.array([5, 10])

print("Третий заказ", old[2].tolist())
print("Новый прогноз", new.tolist())
print("Разность", (new - old).tolist())
