import pandas as pd

orders = pd.read_csv("orders-quality.csv")
train = orders.loc[orders["day"] <= 10]
validation = orders.loc[orders["day"].between(11, 14)]

constant = train["price"].median()
absolute = (validation["price"] - constant).abs()
print("Медиана train", constant)
print("Абсолютные ошибки", absolute.tolist())
print("MAE validation", absolute.mean())
