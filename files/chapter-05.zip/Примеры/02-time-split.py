import pandas as pd

orders = pd.read_csv("orders-quality.csv")
if orders["order_id"].duplicated().any():
    raise ValueError("Проверьте повторяющиеся номера заказов")
day = orders["day"]
parts = {
    "train": orders.loc[day <= 10],
    "validation": orders.loc[day.between(11, 14)],
    "test": orders.loc[day >= 15],
}
for name, part in parts.items():
    first = part["day"].min()
    last = part["day"].max()
    print(name, len(part), "дни", first, last)
