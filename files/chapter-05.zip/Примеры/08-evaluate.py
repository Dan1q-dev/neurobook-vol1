import pandas as pd

orders = pd.read_csv("orders-quality.csv")
day = orders["day"]
train = orders.loc[day <= 10]
val = orders.loc[day.between(11, 14)]
test = orders.loc[day >= 15]
express = train.loc[train["service"] == "express"]
if express.empty or val.empty or test.empty:
    raise ValueError("Проверьте срочные train и непустые val, test")

def tariff(rows):
    return 3 * rows["distance_km"] + 2

median_price = train["price"].median()
premium = (express["price"] - tariff(express)).median()

def baseline(rows):
    return median_price

def with_service(rows):
    return tariff(rows) + (rows["service"] == "express") * premium

def mae(rows, estimate):
    return (rows["price"] - estimate).abs().mean()

rules = {"Медиана": baseline, "По расстоянию": tariff,
         "С типом доставки": with_service}
scores = {name: mae(val, rule(val)) for name, rule in rules.items()}
winner = min(scores, key=scores.get)
print(f"Медиана {median_price:.2f}, надбавка {premium:.2f}")
for name, score in scores.items():
    print(f"MAE val / {name} {score:.2f}")
print("Выбрано", winner)
print(f"MAE test / выбранное {mae(test, rules[winner](test)):.2f}")
print(f"MAE test / базовое {mae(test, median_price):.2f}")
