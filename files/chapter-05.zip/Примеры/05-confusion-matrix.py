actual = [1, 1] + [0] * 18
predicted = [1] * 5 + [0] * 15
matrix = [[0, 0], [0, 0]]

if len(actual) != len(predicted):
    raise ValueError("У каждого заказа должен быть прогноз")

for answer, prediction in zip(actual, predicted):
    if answer not in (0, 1) or prediction not in (0, 1):
        raise ValueError("Классы должны быть 0 или 1")
    matrix[answer][prediction] += 1

print("Строка факта 0", matrix[0])
print("Строка факта 1", matrix[1])
