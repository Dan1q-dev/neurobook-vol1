import random

ids = list(range(1, 13))
generator = random.Random(7)
generator.shuffle(ids)

train = ids[:8]
validation = ids[8:10]
test = ids[10:]
print("train", train)
print("validation", validation)
print("test", test)
