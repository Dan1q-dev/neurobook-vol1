from math import sqrt

def errors(actual, predicted):
    if not actual or len(actual) != len(predicted):
        raise ValueError("Нужны пары факта и прогноза")
    absolute = [abs(p - y) for y, p in zip(actual, predicted)]
    mae = sum(absolute) / len(absolute)
    mse = sum(value ** 2 for value in absolute) / len(absolute)
    return mae, sqrt(mse)

actual = [10, 15, 20, 25]
for name, predicted in (
    ("A", [12, 13, 22, 23]),
    ("B", [10, 15, 20, 31]),
):
    mae, rmse = errors(actual, predicted)
    print(f"{name}: MAE {mae:.2f}, RMSE {rmse:.2f}")
