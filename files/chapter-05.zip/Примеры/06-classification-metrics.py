def ratio(numerator, denominator):
    if denominator == 0:
        return "н/о"
    return f"{numerator / denominator:.2f}"

cases = {
    "Модель": (15, 3, 0, 2),
    "Всегда 0": (18, 0, 2, 0),
}
for name, (tn, fp, fn, tp) in cases.items():
    accuracy = ratio(tn + tp, tn + fp + fn + tp)
    precision = ratio(tp, tp + fp)
    recall = ratio(tp, tp + fn)
    f1 = ratio(2 * tp, 2 * tp + fp + fn)
    print(name, "accuracy", accuracy, "precision", precision)
    print("recall", recall, "F1", f1)
