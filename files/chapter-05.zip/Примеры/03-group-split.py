import pandas as pd

orders = pd.read_csv("orders-quality.csv")
customers = {
    "train": [31, 32, 33, 34, 35, 36, 37, 38],
    "validation": [39, 40],
    "test": [41, 42],
}
for name, ids in customers.items():
    part = orders.loc[orders["customer_id"].isin(ids)]
    count_31 = (part["customer_id"] == 31).sum()
    print(name, len(part), "заказов клиента 31", count_31)
