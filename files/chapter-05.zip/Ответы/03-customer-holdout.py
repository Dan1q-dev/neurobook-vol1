import pandas as pd

orders = pd.read_csv("orders-quality.csv")
is_31 = orders["customer_id"] == 31
held_out = orders.loc[is_31]
other = orders.loc[~is_31]

print("Заказы 31", held_out["order_id"].tolist())
print("Дни", held_out["day"].tolist())
print("Заказов клиента 31 у остальных",
      (other["customer_id"] == 31).sum())
