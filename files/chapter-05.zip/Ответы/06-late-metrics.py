actual = [1, 1] + [0] * 18
predicted = [1, 0, 1] + [0] * 17
matrix = [[0, 0], [0, 0]]
for answer, prediction in zip(actual, predicted):
    matrix[answer][prediction] += 1

tn, fp = matrix[0]
fn, tp = matrix[1]
print("TN, FP, FN, TP", tn, fp, fn, tp)
print(f"Accuracy {(tn + tp) / len(actual):.2f}")
print(f"Precision {tp / (tp + fp):.2f}")
print(f"Recall {tp / (tp + fn):.2f}")
print(f"F1 {2 * tp / (2 * tp + fp + fn):.2f}")
