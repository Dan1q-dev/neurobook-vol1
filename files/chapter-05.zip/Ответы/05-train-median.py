import pandas as pd

orders = pd.read_csv("orders-quality.csv")
train = orders.loc[orders["day"] <= 5]
val = orders.loc[orders["day"].between(11, 14)]
constant = train["price"].median()
errors = (val["price"] - constant).abs()
print("Константа", constant)
print("Ошибки", errors.tolist())
print("MAE", errors.mean())
