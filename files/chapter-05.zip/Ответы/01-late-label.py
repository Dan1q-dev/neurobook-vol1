promised = 720
arrivals = [710, 720, 735]
labels = [int(arrival > promised) for arrival in arrivals]
print("Метки опоздания", labels)
