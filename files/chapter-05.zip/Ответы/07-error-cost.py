counts = {
    "Исходная модель": (3, 0),
    "Модель из задания 6": (1, 1),
    "Всегда 0": (0, 2),
}
for name, (fp, fn) in counts.items():
    cost = fp + 5 * fn
    print(name, cost)
