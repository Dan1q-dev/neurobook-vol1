import pandas as pd

orders = pd.read_csv("orders-quality.csv")
test = orders.loc[orders["day"] >= 15].copy()
express = test["service"] == "express"
predicted = 3 * test["distance_km"] + 2 + express * 4
test["error"] = (test["price"] - predicted).abs()
for service in ("standard", "express"):
    group = test.loc[test["service"] == service, "error"]
    print(service, "заказов", len(group), "MAE", group.mean())
