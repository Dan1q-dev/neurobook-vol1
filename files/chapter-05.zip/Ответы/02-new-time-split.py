import pandas as pd

orders = pd.read_csv("orders-quality.csv")
day = orders["day"]
parts = {
    "train": orders.loc[day <= 9],
    "validation": orders.loc[day.between(10, 13)],
    "test": orders.loc[day >= 14],
}
for name, part in parts.items():
    numbers = part["order_id"]
    print(name, len(part), numbers.min(), numbers.max())
