from math import sqrt

actual = [10, 15, 20, 25]
rules = {"A": [12, 13, 22, 23], "B": [10, 15, 20, 29]}
for name, predicted in rules.items():
    errors = [abs(p - y) for y, p in zip(actual, predicted)]
    mae = sum(errors) / len(errors)
    rmse = sqrt(sum(e ** 2 for e in errors) / len(errors))
    print(name, "ошибки", errors)
    print(f"MAE {mae:.2f}, RMSE {rmse:.2f}")
