probabilities = [0.2, 0.499, 0.5, 0.8]
for threshold in (0.5, 0.7):
    labels = [int(p >= threshold) for p in probabilities]
    print("Порог", threshold, "классы", labels)
