from math import exp, log
from statistics import mean

x, y = [-1, 1], [0, 1]

def probabilities(w, b):
    return [1 / (1 + exp(-(w * a + b))) for a in x]

def loss(p):
    return -mean(log(p_i if y_i == 1 else 1 - p_i)
                 for p_i, y_i in zip(p, y))

w, b, rate = 0.0, 0.0, 1.0
before = probabilities(w, b)
errors = [p_i - y_i for p_i, y_i in zip(before, y)]
dw = mean(e * a for e, a in zip(errors, x))
db = mean(errors)
w, b = w - rate * dw, b - rate * db
after = probabilities(w, b)
print(f"dw {dw:.3f}, db {db:.3f}, w {w:.3f}, b {b:.3f}")
print("Новые p", [round(value, 6) for value in after])
print(f"Потеря до {loss(before):.6f}, после {loss(after):.6f}")
