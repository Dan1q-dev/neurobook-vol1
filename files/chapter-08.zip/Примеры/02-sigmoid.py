from math import exp

def sigmoid(z):
    if z >= 0:
        return 1 / (1 + exp(-z))
    value = exp(z)
    return value / (1 + value)

for distance in (2, 4, 6):
    z = distance - 4
    p = sigmoid(z)
    print(f"{distance} км, z {z}, p {p:.6f}, 1-p {1-p:.6f}")
