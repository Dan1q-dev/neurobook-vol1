from math import log

def loss(y, p):
    if y not in (0, 1) or not 0 < p < 1:
        raise ValueError("Ожидаются метка 0 или 1 и вероятность в (0, 1)")
    correct = p if y == 1 else 1 - p
    return -log(correct)

p = 0.8
values = [loss(y, p) for y in (1, 0)]
print(f"y = 1: {values[0]:.6f}")
print(f"y = 0: {values[1]:.6f}")
print(f"Средняя потеря {sum(values) / len(values):.6f}")
