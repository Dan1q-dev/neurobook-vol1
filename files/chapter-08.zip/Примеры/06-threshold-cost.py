p = [0.85, 0.72, 0.65, 0.55, 0.40, 0.32, 0.20, 0.10]
y = [1, 0, 1, 0, 1, 0, 0, 0]

for threshold in (0.30, 0.50, 0.70):
    matrix = [[0, 0], [0, 0]]
    for probability, fact in zip(p, y):
        label = int(probability >= threshold)
        matrix[fact][label] += 1
    tn, fp = matrix[0]
    fn, tp = matrix[1]
    cost = fp + 5 * fn
    accuracy = (tn + tp) / len(y)
    print(f"Порог {threshold:.2f}", "TN FP FN TP", tn, fp, fn, tp)
    print(f"accuracy {accuracy:.3f}, цена {cost}")
