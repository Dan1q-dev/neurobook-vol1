short_total, short_late = 12, 2
long_total, long_late = 8, 4
total = short_total + long_total
late = short_late + long_late

print(f"Доля опозданий {late / total:.4f}")
print(f"Опоздание при дальнем маршруте {long_late / long_total:.4f}")
print(f"Дальний маршрут при опоздании {long_late / late:.4f}")
