import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, log_loss

orders = pd.read_csv("orders-late.csv")
day = orders["day"]
train = orders.loc[day <= 20]
val = orders.loc[day.between(21, 28)]
test = orders.loc[day >= 29]
if not orders["late"].isin([0, 1]).all():
    raise ValueError("В late должны быть только 0 и 1")
if set(train["late"]) != {0, 1} or val.empty or test.empty:
    raise ValueError("Нужны оба класса в train и непустые val и test")
cols = ["distance_km", "rush"]
model = LogisticRegression(max_iter=1000)
model.fit(train[cols], train["late"])
w_dist, w_rush = model.coef_[0]
b = model.intercept_[0]
print(f"Веса {w_dist:.3f}, {w_rush:.3f}, смещение {b:.3f}")

def counts(y, p, threshold):
    predicted = (p >= threshold).astype(int)
    return confusion_matrix(y, predicted, labels=[0, 1]).ravel()

p_val = model.predict_proba(val[cols])[:, 1]
costs = {}
for t in (0.30, 0.50, 0.70):
    tn, fp, fn, tp = counts(val["late"], p_val, t)
    costs[t] = fp + 5 * fn
    print(f"val {t:.2f}", tn, fp, fn, tp, "цена", costs[t])
threshold = min(costs, key=costs.get)
print(f"Выбранный порог {threshold:.2f}")

p_test = model.predict_proba(test[cols])[:, 1]
tn, fp, fn, tp = counts(test["late"], p_test, threshold)
print("test TN FP FN TP", tn, fp, fn, tp)
print("Цена test", fp + 5 * fn)
test_loss = log_loss(
    test["late"], p_test, labels=[0, 1]
)
print(f"log loss test {test_loss:.6f}")
