from statistics import mean

groups = (
    ("Низкий риск", [0.20] * 10, [1] * 2 + [0] * 8),
    ("Высокий риск", [0.70] * 10, [1] * 5 + [0] * 5),
)
for name, predicted, actual in groups:
    print(name, "заказов", len(actual))
    print(f"Среднее p {mean(predicted):.2f}, доля {mean(actual):.2f}")
