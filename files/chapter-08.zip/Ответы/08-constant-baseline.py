import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, log_loss

orders = pd.read_csv("orders-late.csv")
train = orders.loc[orders["day"] <= 20]
test = orders.loc[orders["day"] >= 29]
cols = ["distance_km", "rush"]
model = LogisticRegression(max_iter=1000).fit(train[cols], train["late"])
actual = test["late"]
base = train["late"].mean()
print(f"Базовая вероятность {base:.6f}")
candidates = (("Модель", model.predict_proba(test[cols])[:, 1]),
              ("База", [base] * len(test)))
for name, p in candidates:
    labels = [int(value >= 0.30) for value in p]
    tn, fp, fn, tp = confusion_matrix(actual, labels, labels=[0, 1]).ravel()
    price = fp + 5 * fn
    loss = log_loss(actual, p, labels=[0, 1])
    print(f"{name}: цена {price}, log loss {loss:.6f}")
