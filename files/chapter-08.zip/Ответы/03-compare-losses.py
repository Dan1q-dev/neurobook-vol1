from math import log

for y in (1, 0):
    for p in (0.9, 0.6):
        correct = p if y == 1 else 1 - p
        label = int(p >= 0.5)
        print(f"y {y}, p {p:.1f}, класс {label}, потеря {-log(correct):.6f}")
