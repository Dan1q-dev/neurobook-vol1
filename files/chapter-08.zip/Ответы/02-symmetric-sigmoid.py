from math import exp

for distance in (1, 4, 7):
    z = distance - 4
    p = 1 / (1 + exp(-z))
    label = int(p >= 0.5)
    print(f"{distance} км, z {z}, p {p:.6f}, класс {label}")
