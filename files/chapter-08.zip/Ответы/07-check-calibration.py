from statistics import mean

groups = (([0.1, 0.2, 0.3, 0.2, 0.2], 2),
          ([0.6, 0.7, 0.8, 0.7, 0.7], 3))
for number, (p, late) in enumerate(groups, start=1):
    average = mean(p)
    observed = late / len(p)
    print(f"{number}: среднее p {average:.2f}, доля {observed:.2f}")
