p = [0.85, 0.72, 0.65, 0.55, 0.40, 0.32, 0.20, 0.10]
y = [1, 0, 1, 0, 1, 0, 0, 0]
decisions = [int(value >= 0.65) for value in p]
matrix = [[0, 0], [0, 0]]
for fact, label in zip(y, decisions):
    matrix[fact][label] += 1
tn, fp = matrix[0]
fn, tp = matrix[1]
print("Предупреждений", sum(decisions), "подтвердились", tp)
print("TN FP FN TP", tn, fp, fn, tp)
print(f"precision {tp / (tp + fp):.4f}, recall {tp / (tp + fn):.4f}")
print(f"accuracy {(tn + tp) / len(y):.4f}")
