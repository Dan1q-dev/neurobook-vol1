from math import exp, log
from statistics import mean

x, y = [-1, 1], [0, 1]
errors = [0.5 - label for label in y]
dw = mean(error * a for error, a in zip(errors, x))
db = mean(errors)
w, b = 0.0, 0.0
w, b = w - 0.5 * dw, b - 0.5 * db
p = [1 / (1 + exp(-(w * a + b))) for a in x]
loss = -mean(log(value if label else 1 - value)
             for value, label in zip(p, y))
print(f"w {w:.3f}, b {b:.3f}")
print("Вероятности", [round(value, 6) for value in p])
print(f"Средняя потеря {loss:.6f}")
