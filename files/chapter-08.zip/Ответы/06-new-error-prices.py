counts = {0.30: (3, 0), 0.50: (2, 1), 0.70: (1, 2)}
costs = {}
for threshold, (fp, fn) in counts.items():
    costs[threshold] = 2 * fp + fn
    print(f"Порог {threshold:.2f}, цена {costs[threshold]}")
chosen = min(costs, key=costs.get)
print(f"Выбранный порог {chosen:.2f}")
