short_late = 2
short_total, all_late = 12, 6
long_on_time, long_total = 4, 8
print(f"Опоздание среди коротких {short_late / short_total:.4f}")
print(f"Короткий среди опозданий {short_late / all_late:.4f}")
print(f"Вовремя среди дальних {long_on_time / long_total:.4f}")
